import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Loader2, Lock, Mail, ArrowLeft, Eye, EyeOff, AlertCircle, CheckCircle2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { isValidEmail } from '@/lib/crm';
import { IMG } from '@/data/site';

type Mode = 'signin' | 'signup' | 'reset';

export default function AdminLogin() {
  const [mode, setMode] = useState<Mode>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');

  const switchMode = (m: Mode) => {
    setMode(m);
    setError('');
    setInfo('');
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setInfo('');
    if (!isValidEmail(email)) return setError('Please enter a valid email address.');
    if (mode !== 'reset' && password.length < 8) return setError('Password must be at least 8 characters.');
    setLoading(true);
    try {
      if (mode === 'signin') {
        const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (error) throw error;
      } else if (mode === 'signup') {
        const { data, error } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: { emailRedirectTo: `${window.location.origin}/admin` },
        });
        if (error) throw error;
        if (!data.session) {
          setInfo('Account created. Check your inbox to confirm your email, then sign in.');
          setMode('signin');
        }
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
          redirectTo: `${window.location.origin}/admin`,
        });
        if (error) throw error;
        setInfo('If an account exists for that email, a password reset link has been sent.');
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Something went wrong.';
      setError(/invalid login/i.test(msg) ? 'Incorrect email or password.' : msg);
    } finally {
      setLoading(false);
    }
  };

  const titles: Record<Mode, string> = {
    signin: 'Team Sign In',
    signup: 'Create Team Account',
    reset: 'Reset Password',
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-ivory">
      <div className="relative hidden lg:block">
        <img src={IMG.registryRoom} alt="" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-br from-liberty-950/90 via-liberty-900/75 to-charcoal/90" />
        <div className="relative h-full flex flex-col justify-between p-14 text-white">
          <Link to="/" className="inline-flex items-center gap-2 text-white/70 hover:text-white text-sm">
            <ArrowLeft className="w-4 h-4" /> Back to website
          </Link>
          <div>
            <div className="eyebrow text-liberty-200">Ellis Island Events</div>
            <h1 className="font-serif text-4xl mt-4 leading-tight">Inquiry Management</h1>
            <p className="mt-4 font-display text-xl text-white/75 max-w-md">
              Review event inquiries, track every proposal and keep the whole team aligned.
            </p>
          </div>
          <p className="text-xs text-white/50">Authorized Evelyn Hill Inc. personnel only.</p>
        </div>
      </div>

      <div className="flex items-center justify-center p-6 sm:p-12">
        <div className="w-full max-w-md">
          <div className="flex items-center gap-4 mb-10">
            <img src={IMG.logo} alt="Evelyn Hill Inc." className="h-16 w-auto bg-white p-0.5 shadow-sm" />
            <div>
              <div className="font-serif text-lg tracking-[0.1em]">Ellis Island Events</div>
              <div className="font-serif text-liberty-600 text-[10px] tracking-[0.3em] uppercase">Admin Portal</div>
            </div>
          </div>

          <h2 className="font-serif text-3xl">{titles[mode]}</h2>
          <p className="mt-2 text-charcoal/60 text-sm">
            {mode === 'signup'
              ? 'Use your company email. Access is granted only to emails on the admin list.'
              : mode === 'reset'
              ? 'Enter your email and we will send you a reset link.'
              : 'Sign in with your team email and password.'}
          </p>

          <form onSubmit={submit} noValidate className="mt-8 space-y-5">
            <div>
              <label htmlFor="admin-email" className="field-label">Email</label>
              <div className="relative">
                <Mail className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-charcoal/40" />
                <input id="admin-email" type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} className="field pl-10" placeholder="you@ehillgroup.com" />
              </div>
            </div>
            {mode !== 'reset' && (
              <div>
                <label htmlFor="admin-password" className="field-label">Password</label>
                <div className="relative">
                  <Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-charcoal/40" />
                  <input
                    id="admin-password"
                    type={show ? 'text' : 'password'}
                    autoComplete={mode === 'signup' ? 'new-password' : 'current-password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="field pl-10 pr-11"
                    placeholder="At least 8 characters"
                  />
                  <button type="button" onClick={() => setShow((s) => !s)} className="absolute right-3 top-1/2 -translate-y-1/2 text-charcoal/40 hover:text-charcoal" aria-label={show ? 'Hide password' : 'Show password'}>
                    {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}

            {error && (
              <div className="flex items-start gap-2 text-sm text-red-700 bg-red-50 border border-red-200 px-4 py-3">
                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" /> {error}
              </div>
            )}
            {info && (
              <div className="flex items-start gap-2 text-sm text-liberty-800 bg-liberty-50 border border-liberty-200 px-4 py-3">
                <CheckCircle2 className="w-4 h-4 mt-0.5 shrink-0" /> {info}
              </div>
            )}

            <button type="submit" disabled={loading} className="btn-primary w-full disabled:opacity-60">
              {loading && <Loader2 className="w-4 h-4 animate-spin" />}
              {mode === 'signin' ? 'Sign In' : mode === 'signup' ? 'Create Account' : 'Send Reset Link'}
            </button>
          </form>

          <div className="mt-6 flex flex-wrap justify-between gap-3 text-sm">
            {mode === 'signin' ? (
              <>
                <button onClick={() => switchMode('reset')} className="text-liberty-700 hover:underline">Forgot password?</button>
                <button onClick={() => switchMode('signup')} className="text-liberty-700 hover:underline">First time? Create account</button>
              </>
            ) : (
              <button onClick={() => switchMode('signin')} className="text-liberty-700 hover:underline">Back to sign in</button>
            )}
          </div>

          <Link to="/" className="lg:hidden mt-10 inline-flex items-center gap-2 text-charcoal/60 hover:text-charcoal text-sm">
            <ArrowLeft className="w-4 h-4" /> Back to website
          </Link>
        </div>
      </div>
    </div>
  );
}
