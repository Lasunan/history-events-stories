import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Download, RefreshCw, LogOut, KeyRound, ExternalLink, Inbox, ChevronLeft, ChevronRight, ArrowUpDown,
  StickyNote, Loader2, AlertCircle, Users, CalendarDays, FileText, MessageSquare,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { IMG } from '@/data/site';
import {
  INQUIRY_STATUSES, STATUS_STYLES, EMPTY_FILTERS, applyFilters, exportInquiriesCsv, fmtDate,
  type Inquiry, type InquiryNote, type InquiryStatus, type InquiryFilters,
} from '@/lib/inquiries';
import InquiryFiltersBar from './InquiryFiltersBar';
import InquiryDetail from './InquiryDetail';
import StatusBadge from './StatusBadge';
import ChangePasswordModal from './ChangePasswordModal';
import PagesEditor from './PagesEditor';
import ChatConversations from './ChatConversations';

type SortKey = 'created_at' | 'event_date' | 'name' | 'guest_count';
const PAGE_SIZE = 20;

export default function AdminDashboard({ email, onSignOut }: { email: string; onSignOut: () => void }) {
  const [tab, setTab] = useState<'inquiries' | 'chats' | 'pages'>('inquiries');
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);
  const [notes, setNotes] = useState<Record<string, InquiryNote[]>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filters, setFilters] = useState<InquiryFilters>(EMPTY_FILTERS);
  const [sort, setSort] = useState<{ key: SortKey; dir: 'asc' | 'desc' }>({ key: 'created_at', dir: 'desc' });
  const [page, setPage] = useState(1);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [pwOpen, setPwOpen] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    const [inqRes, notesRes] = await Promise.all([
      supabase.from('event_inquiries').select('*').order('created_at', { ascending: false }),
      supabase.from('inquiry_notes').select('*').order('created_at', { ascending: false }),
    ]);
    if (inqRes.error) setError('Could not load inquiries. Please refresh.');
    setInquiries((inqRes.data as Inquiry[]) || []);
    const grouped: Record<string, InquiryNote[]> = {};
    ((notesRes.data as InquiryNote[]) || []).forEach((n) => (grouped[n.inquiry_id] ||= []).push(n));
    setNotes(grouped);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);
  useEffect(() => setPage(1), [filters, sort]);

  const counts = useMemo(() => {
    const c = Object.fromEntries(INQUIRY_STATUSES.map((s) => [s, 0])) as Record<InquiryStatus, number>;
    inquiries.forEach((i) => { c[i.status] = (c[i.status] || 0) + 1; });
    return c;
  }, [inquiries]);

  const upcoming = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);
    return inquiries.filter((i) => i.status === 'Booked' && i.event_date && i.event_date >= today).length;
  }, [inquiries]);

  const filtered = useMemo(() => {
    const list = applyFilters(inquiries, filters);
    const dir = sort.dir === 'asc' ? 1 : -1;
    return [...list].sort((a, b) => {
      let av: string | number = '', bv: string | number = '';
      if (sort.key === 'name') { av = `${a.last_name} ${a.first_name}`.toLowerCase(); bv = `${b.last_name} ${b.first_name}`.toLowerCase(); }
      else if (sort.key === 'guest_count') { av = a.guest_count ?? -1; bv = b.guest_count ?? -1; }
      else if (sort.key === 'event_date') { av = a.event_date ?? (dir === 1 ? '9999' : ''); bv = b.event_date ?? (dir === 1 ? '9999' : ''); }
      else { av = a.created_at; bv = b.created_at; }
      return av < bv ? -dir : av > bv ? dir : 0;
    });
  }, [inquiries, filters, sort]);

  const pages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const pageItems = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
  const selected = inquiries.find((i) => i.id === selectedId) || null;

  const toggleSort = (key: SortKey) =>
    setSort((s) => (s.key === key ? { key, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key, dir: key === 'name' ? 'asc' : 'desc' }));

  const updateStatus = async (id: string, status: InquiryStatus) => {
    const prev = inquiries;
    const updated_at = new Date().toISOString();
    setInquiries((list) => list.map((i) => (i.id === id ? { ...i, status, updated_at } : i)));
    const { error } = await supabase.from('event_inquiries').update({ status, updated_at }).eq('id', id);
    if (error) { setInquiries(prev); return false; }
    return true;
  };

  const deleteInquiry = async (id: string) => {
    const { error } = await supabase.from('event_inquiries').delete().eq('id', id);
    if (error) return false;
    setInquiries((list) => list.filter((i) => i.id !== id));
    setSelectedId(null);
    return true;
  };

  const SortTh = ({ k, children, className = '' }: { k: SortKey; children: React.ReactNode; className?: string }) => (
    <th className={`px-4 py-3 font-medium ${className}`}>
      <button onClick={() => toggleSort(k)} className={`inline-flex items-center gap-1 hover:text-zinc-900 ${sort.key === k ? 'text-zinc-900' : ''}`}>
        {children} <ArrowUpDown className={`w-3 h-3 ${sort.key === k ? 'opacity-100' : 'opacity-40'}`} />
      </button>
    </th>
  );

  return (
    <div className="min-h-screen bg-zinc-50 font-sans">
      <header className="bg-charcoal text-white sticky top-0 z-40">
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <img src={IMG.logo} alt="" className="h-10 w-auto bg-white p-0.5" />
            <div className="min-w-0">
              <div className="font-serif tracking-[0.1em] truncate">Ellis Island Events</div>
              <div className="text-[10px] tracking-[0.3em] uppercase text-liberty-300">Admin · CRM & Pages</div>
            </div>
          </div>
          <div className="flex items-center gap-1 sm:gap-2">
            <span className="hidden md:block text-sm text-white/60 mr-2 truncate max-w-[220px]">{email}</span>
            <Link to="/" className="p-2 text-white/70 hover:text-white" title="View website"><ExternalLink className="w-4 h-4" /></Link>
            <button onClick={() => setPwOpen(true)} className="p-2 text-white/70 hover:text-white" title="Change password"><KeyRound className="w-4 h-4" /></button>
            <button onClick={onSignOut} className="inline-flex items-center gap-2 px-3 py-2 text-sm text-white/80 hover:text-white hover:bg-white/10 rounded">
              <LogOut className="w-4 h-4" /> <span className="hidden sm:inline">Sign out</span>
            </button>
          </div>
        </div>
        <div className="border-t border-white/10">
          <nav className="max-w-[1400px] mx-auto px-4 sm:px-6 flex gap-1 overflow-x-auto" aria-label="Admin sections">
            {([['inquiries', 'Inquiries', Inbox], ['chats', 'AI Chats', MessageSquare], ['pages', 'Pages', FileText]] as const).map(([key, label, I]) => (
              <button
                key={key}
                onClick={() => setTab(key)}
                className={`inline-flex items-center gap-2 px-4 py-3 text-sm border-b-2 whitespace-nowrap transition ${tab === key ? 'border-liberty-400 text-white' : 'border-transparent text-white/60 hover:text-white'}`}
              >
                <I className="w-4 h-4" /> {label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      {tab === 'pages' && (
        <main className="max-w-[1400px] mx-auto px-4 sm:px-6 py-8">
          <PagesEditor email={email} />
        </main>
      )}

      {tab === 'chats' && (
        <main className="max-w-[1400px] mx-auto px-4 sm:px-6 py-8">
          <ChatConversations
            onOpenInquiry={async (id) => {
              if (!inquiries.some((i) => i.id === id)) await load();
              setTab('inquiries');
              setSelectedId(id);
            }}
          />
        </main>
      )}

      <main className={`max-w-[1400px] mx-auto px-4 sm:px-6 py-8 space-y-6 ${tab !== 'inquiries' ? 'hidden' : ''}`}>
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <h1 className="font-serif text-2xl sm:text-3xl text-zinc-900">Event Inquiries</h1>
            <p className="text-sm text-zinc-500 mt-1">{inquiries.length} total · {upcoming} upcoming booked events</p>
          </div>
          <div className="flex gap-2">
            <button onClick={load} disabled={loading} className="h-10 px-4 inline-flex items-center gap-2 rounded-md border border-zinc-200 bg-white text-sm text-zinc-700 hover:bg-zinc-50 disabled:opacity-50">
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /> Refresh
            </button>
            <button
              onClick={() => exportInquiriesCsv(filtered, notes)}
              disabled={!filtered.length}
              className="h-10 px-4 inline-flex items-center gap-2 rounded-md bg-liberty-600 text-white text-sm hover:bg-liberty-700 disabled:opacity-50"
            >
              <Download className="w-4 h-4" /> Export CSV ({filtered.length})
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
          <button
            onClick={() => setFilters((f) => ({ ...f, status: '' }))}
            className={`text-left bg-white rounded-lg border p-4 transition hover:shadow-sm ${!filters.status ? 'border-liberty-500 ring-1 ring-liberty-500' : 'border-zinc-200'}`}
          >
            <div className="flex items-center gap-2 text-xs text-zinc-500"><Inbox className="w-3.5 h-3.5" /> All</div>
            <div className="text-2xl font-semibold text-zinc-900 mt-1">{inquiries.length}</div>
          </button>
          {INQUIRY_STATUSES.map((s) => (
            <button
              key={s}
              onClick={() => setFilters((f) => ({ ...f, status: f.status === s ? '' : s }))}
              className={`text-left bg-white rounded-lg border p-4 transition hover:shadow-sm ${filters.status === s ? 'border-liberty-500 ring-1 ring-liberty-500' : 'border-zinc-200'}`}
            >
              <div className="flex items-center gap-2 text-xs text-zinc-500"><span className={`w-2 h-2 rounded-full ${STATUS_STYLES[s].dot}`} /> {s}</div>
              <div className="text-2xl font-semibold text-zinc-900 mt-1">{counts[s]}</div>
            </button>
          ))}
        </div>

        <InquiryFiltersBar filters={filters} onChange={setFilters} />

        {error && (
          <div className="flex items-center gap-2 text-sm text-red-700 bg-red-50 border border-red-200 rounded-md px-4 py-3">
            <AlertCircle className="w-4 h-4" /> {error}
          </div>
        )}

        <div className="bg-white border border-zinc-200 rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-zinc-50 text-left text-xs uppercase tracking-wider text-zinc-500 border-b border-zinc-200">
                <tr>
                  <SortTh k="name">Contact</SortTh>
                  <th className="px-4 py-3 font-medium">Event</th>
                  <SortTh k="event_date">Event Date</SortTh>
                  <SortTh k="guest_count" className="text-right">Guests</SortTh>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <SortTh k="created_at">Submitted</SortTh>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-100">
                {loading && !inquiries.length ? (
                  <tr><td colSpan={6} className="px-4 py-16 text-center text-zinc-400"><Loader2 className="w-6 h-6 animate-spin mx-auto" /></td></tr>
                ) : pageItems.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-4 py-16 text-center">
                      <Inbox className="w-10 h-10 text-zinc-300 mx-auto" />
                      <p className="mt-3 text-zinc-500">{inquiries.length ? 'No inquiries match these filters.' : 'No inquiries yet. Submissions from the website form will appear here.'}</p>
                    </td>
                  </tr>
                ) : (
                  pageItems.map((i) => (
                    <tr key={i.id} onClick={() => setSelectedId(i.id)} className={`cursor-pointer hover:bg-liberty-50/50 transition ${i.status === 'New' ? 'bg-sky-50/30' : ''}`}>
                      <td className="px-4 py-3.5">
                        <div className="font-medium text-zinc-900 flex items-center gap-2">
                          {i.first_name} {i.last_name}
                          {notes[i.id]?.length ? (
                            <span className="inline-flex items-center gap-0.5 text-[11px] text-zinc-400" title={`${notes[i.id].length} notes`}>
                              <StickyNote className="w-3 h-3" />{notes[i.id].length}
                            </span>
                          ) : null}
                        </div>
                        <div className="text-zinc-500 text-xs truncate max-w-[240px]">{i.email}{i.company ? ` · ${i.company}` : ''}</div>
                      </td>
                      <td className="px-4 py-3.5">
                        <div className="text-zinc-800">{i.event_type}</div>
                        <div className="text-zinc-500 text-xs truncate max-w-[240px]">{i.venue || 'No venue preference'}</div>
                      </td>
                      <td className="px-4 py-3.5 whitespace-nowrap text-zinc-700">
                        <span className="inline-flex items-center gap-1.5"><CalendarDays className="w-3.5 h-3.5 text-zinc-400" />{fmtDate(i.event_date)}</span>
                      </td>
                      <td className="px-4 py-3.5 text-right text-zinc-700 whitespace-nowrap">
                        {i.guest_count ? <span className="inline-flex items-center gap-1"><Users className="w-3.5 h-3.5 text-zinc-400" />{i.guest_count.toLocaleString()}</span> : '—'}
                      </td>
                      <td className="px-4 py-3.5" onClick={(e) => e.stopPropagation()}>
                        <div className="relative inline-block">
                          <StatusBadge status={i.status} />
                          <select
                            value={i.status}
                            onChange={(e) => updateStatus(i.id, e.target.value as InquiryStatus)}
                            className="absolute inset-0 opacity-0 cursor-pointer"
                            aria-label={`Change status for ${i.first_name} ${i.last_name}`}
                          >
                            {INQUIRY_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                          </select>
                        </div>
                      </td>
                      <td className="px-4 py-3.5 whitespace-nowrap text-zinc-500 text-xs">{fmtDate(i.created_at, true)}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {filtered.length > PAGE_SIZE && (
            <div className="flex items-center justify-between px-4 py-3 border-t border-zinc-200 text-sm text-zinc-600">
              <span>
                Showing {(page - 1) * PAGE_SIZE + 1}–{Math.min(page * PAGE_SIZE, filtered.length)} of {filtered.length}
              </span>
              <div className="flex items-center gap-1">
                <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1} className="p-2 rounded hover:bg-zinc-100 disabled:opacity-40" aria-label="Previous page"><ChevronLeft className="w-4 h-4" /></button>
                <span className="px-2">Page {page} of {pages}</span>
                <button onClick={() => setPage((p) => Math.min(pages, p + 1))} disabled={page === pages} className="p-2 rounded hover:bg-zinc-100 disabled:opacity-40" aria-label="Next page"><ChevronRight className="w-4 h-4" /></button>
              </div>
            </div>
          )}
        </div>
      </main>

      <InquiryDetail
        inquiry={selected}
        notes={selected ? notes[selected.id] || [] : []}
        authorEmail={email}
        onClose={() => setSelectedId(null)}
        onStatusChange={updateStatus}
        onNoteAdded={(n) => setNotes((m) => ({ ...m, [n.inquiry_id]: [n, ...(m[n.inquiry_id] || [])] }))}
        onNoteDeleted={(n) => setNotes((m) => ({ ...m, [n.inquiry_id]: (m[n.inquiry_id] || []).filter((x) => x.id !== n.id) }))}
        onDelete={deleteInquiry}
      />
      <ChangePasswordModal open={pwOpen} onClose={() => setPwOpen(false)} />
    </div>
  );
}
