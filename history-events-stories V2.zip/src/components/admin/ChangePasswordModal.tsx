import { useState } from 'react';
import { X, Loader2, CheckCircle2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';

export default function ChangePasswordModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [pw, setPw] = useState('');
  const [confirm, setConfirm] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);

  if (!open) return null;

  const close = () => {
    setPw(''); setConfirm(''); setError(''); setDone(false);
    onClose();
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (pw.length < 8) return setError('Password must be at least 8 characters.');
    if (pw !== confirm) return setError('Passwords do not match.');
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password: pw });
    setLoading(false);
    if (error) return setError(error.message);
    setDone(true);
  };

  return (
    <div className="fixed inset-0 z-[60] bg-charcoal/50 flex items-center justify-center p-4" onClick={close}>
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-sm p-6 relative" onClick={(e) => e.stopPropagation()}>
        <button onClick={close} className="absolute top-4 right-4 text-zinc-400 hover:text-zinc-800" aria-label="Close"><X className="w-5 h-5" /></button>
        <h3 className="font-serif text-xl">Change Password</h3>
        {done ? (
          <div className="mt-6 text-center">
            <CheckCircle2 className="w-10 h-10 text-liberty-600 mx-auto" />
            <p className="mt-3 text-sm text-zinc-600">Your password has been updated.</p>
            <button onClick={close} className="btn-primary w-full mt-6 !py-2.5">Done</button>
          </div>
        ) : (
          <form onSubmit={submit} className="mt-5 space-y-4">
            <div>
              <label className="field-label" htmlFor="new-pw">New password</label>
              <input id="new-pw" type="password" autoComplete="new-password" value={pw} onChange={(e) => setPw(e.target.value)} className="field" />
            </div>
            <div>
              <label className="field-label" htmlFor="confirm-pw">Confirm password</label>
              <input id="confirm-pw" type="password" autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} className="field" />
            </div>
            {error && <p className="text-sm text-red-600">{error}</p>}
            <button type="submit" disabled={loading} className="btn-primary w-full !py-2.5 disabled:opacity-60">
              {loading && <Loader2 className="w-4 h-4 animate-spin" />} Update Password
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
