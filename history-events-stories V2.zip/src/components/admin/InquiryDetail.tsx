import { useEffect, useState } from 'react';
import {
  X, Mail, Phone, Building2, CalendarDays, Users, MapPin, Tag, MessageSquare, Loader2, Send, Trash2, Clock, Check,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { INQUIRY_STATUSES, STATUS_STYLES, fmtDate, type Inquiry, type InquiryNote, type InquiryStatus } from '@/lib/inquiries';

interface Props {
  inquiry: Inquiry | null;
  notes: InquiryNote[];
  authorEmail: string;
  onClose: () => void;
  onStatusChange: (id: string, status: InquiryStatus) => Promise<boolean>;
  onNoteAdded: (note: InquiryNote) => void;
  onNoteDeleted: (note: InquiryNote) => void;
  onDelete: (id: string) => Promise<boolean>;
}

export default function InquiryDetail({ inquiry, notes, authorEmail, onClose, onStatusChange, onNoteAdded, onNoteDeleted, onDelete }: Props) {
  const [draft, setDraft] = useState('');
  const [saving, setSaving] = useState(false);
  const [statusSaving, setStatusSaving] = useState<InquiryStatus | null>(null);
  const [error, setError] = useState('');
  const [confirmDelete, setConfirmDelete] = useState(false);

  useEffect(() => {
    setDraft('');
    setError('');
    setConfirmDelete(false);
  }, [inquiry?.id]);

  useEffect(() => {
    if (!inquiry) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [inquiry, onClose]);

  if (!inquiry) return null;

  const changeStatus = async (s: InquiryStatus) => {
    if (s === inquiry.status) return;
    setStatusSaving(s);
    const ok = await onStatusChange(inquiry.id, s);
    setStatusSaving(null);
    if (!ok) setError('Could not update status. Please try again.');
  };

  const addNote = async (e: React.FormEvent) => {
    e.preventDefault();
    const body = draft.trim();
    if (!body) return;
    setSaving(true);
    setError('');
    const { data, error } = await supabase
      .from('inquiry_notes')
      .insert({ inquiry_id: inquiry.id, body, author_email: authorEmail })
      .select()
      .single();
    setSaving(false);
    if (error || !data) return setError('Could not save note.');
    onNoteAdded(data as InquiryNote);
    setDraft('');
  };

  const deleteNote = async (n: InquiryNote) => {
    const { error } = await supabase.from('inquiry_notes').delete().eq('id', n.id);
    if (error) return setError('Could not delete note.');
    onNoteDeleted(n);
  };

  const Row = ({ icon: I, label, children }: { icon: typeof Mail; label: string; children: React.ReactNode }) => (
    <div className="flex items-start gap-3 py-2.5">
      <I className="w-4 h-4 mt-0.5 text-liberty-600 shrink-0" />
      <div className="min-w-0">
        <div className="text-[11px] uppercase tracking-wider text-zinc-500">{label}</div>
        <div className="text-sm text-zinc-900 break-words">{children}</div>
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 z-50 flex justify-end" role="dialog" aria-modal="true" aria-label="Inquiry details">
      <div className="absolute inset-0 bg-charcoal/40 backdrop-blur-[1px] animate-fade-in" onClick={onClose} />
      <aside className="relative w-full max-w-xl h-full bg-white shadow-2xl flex flex-col animate-slide-in">
        <header className="px-6 py-5 border-b border-zinc-200 flex items-start justify-between gap-4">
          <div className="min-w-0">
            <div className="text-xs text-zinc-500 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5" /> Submitted {fmtDate(inquiry.created_at, true)}
            </div>
            <h2 className="font-serif text-2xl mt-1 truncate">{inquiry.first_name} {inquiry.last_name}</h2>
            {inquiry.company && <div className="text-sm text-zinc-600">{inquiry.company}</div>}
          </div>
          <button onClick={onClose} className="p-2 -mr-2 text-zinc-400 hover:text-zinc-800" aria-label="Close">
            <X className="w-5 h-5" />
          </button>
        </header>

        <div className="flex-1 overflow-y-auto">
          <section className="px-6 py-5 border-b border-zinc-100">
            <div className="text-[11px] uppercase tracking-wider text-zinc-500 mb-3">Status</div>
            <div className="flex flex-wrap gap-2">
              {INQUIRY_STATUSES.map((s) => {
                const active = inquiry.status === s;
                return (
                  <button
                    key={s}
                    onClick={() => changeStatus(s)}
                    disabled={!!statusSaving}
                    className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium ring-1 ring-inset transition ${
                      active ? STATUS_STYLES[s].badge + ' ring-2' : 'bg-white text-zinc-600 ring-zinc-200 hover:ring-zinc-400'
                    }`}
                  >
                    {statusSaving === s ? <Loader2 className="w-3 h-3 animate-spin" /> : active ? <Check className="w-3 h-3" /> : <span className={`w-1.5 h-1.5 rounded-full ${STATUS_STYLES[s].dot}`} />}
                    {s}
                  </button>
                );
              })}
            </div>
            <div className="mt-2 text-xs text-zinc-400">Last updated {fmtDate(inquiry.updated_at, true)}</div>
          </section>

          <section className="px-6 py-4 border-b border-zinc-100 grid sm:grid-cols-2 gap-x-6">
            <Row icon={Mail} label="Email"><a href={`mailto:${inquiry.email}`} className="text-liberty-700 hover:underline">{inquiry.email}</a></Row>
            <Row icon={Phone} label="Phone">
              {inquiry.phone ? <a href={`tel:${inquiry.phone}`} className="text-liberty-700 hover:underline">{inquiry.phone}</a> : '—'}
              {inquiry.phone && <span className="ml-2 text-xs text-zinc-500">{inquiry.sms_opt_in ? '(SMS opt-in)' : '(no SMS)'}</span>}
            </Row>
            <Row icon={Tag} label="Event Type">{inquiry.event_type}</Row>
            <Row icon={MapPin} label="Preferred Venue">{inquiry.venue || 'Not sure yet'}</Row>
            <Row icon={CalendarDays} label="Event Date">{fmtDate(inquiry.event_date)}</Row>
            <Row icon={Users} label="Guests">{inquiry.guest_count ?? '—'}</Row>
            {inquiry.company && <Row icon={Building2} label="Company">{inquiry.company}</Row>}
          </section>

          {inquiry.message && (
            <section className="px-6 py-5 border-b border-zinc-100">
              <div className="text-[11px] uppercase tracking-wider text-zinc-500 mb-2 flex items-center gap-1.5"><MessageSquare className="w-3.5 h-3.5" /> Message</div>
              <p className="text-sm text-zinc-800 whitespace-pre-wrap leading-relaxed bg-zinc-50 border border-zinc-100 p-4">{inquiry.message}</p>
            </section>
          )}

          <section className="px-6 py-5">
            <div className="text-[11px] uppercase tracking-wider text-zinc-500 mb-3">Internal Notes ({notes.length})</div>
            <form onSubmit={addNote} className="space-y-2">
              <textarea
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={(e) => { if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') addNote(e); }}
                rows={3}
                placeholder="Add a note visible only to the team… (Ctrl/Cmd + Enter to save)"
                className="field text-sm resize-none"
              />
              <div className="flex justify-end">
                <button type="submit" disabled={saving || !draft.trim()} className="btn-primary !px-4 !py-2 !text-[11px] disabled:opacity-50">
                  {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />} Add Note
                </button>
              </div>
            </form>
            <ul className="mt-5 space-y-3">
              {notes.length === 0 && <li className="text-sm text-zinc-400">No notes yet.</li>}
              {notes.map((n) => (
                <li key={n.id} className="group border-l-2 border-liberty-300 bg-liberty-50/40 pl-4 pr-3 py-3">
                  <div className="flex items-center justify-between gap-3 text-xs text-zinc-500">
                    <span className="truncate">{n.author_email || 'Team'} · {fmtDate(n.created_at, true)}</span>
                    <button onClick={() => deleteNote(n)} className="opacity-0 group-hover:opacity-100 text-zinc-400 hover:text-red-600 transition" aria-label="Delete note">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <p className="mt-1 text-sm text-zinc-800 whitespace-pre-wrap">{n.body}</p>
                </li>
              ))}
            </ul>
          </section>

          {error && <div className="mx-6 mb-4 text-sm text-red-700 bg-red-50 border border-red-200 px-4 py-2">{error}</div>}
        </div>

        <footer className="px-6 py-4 border-t border-zinc-200 flex flex-wrap items-center justify-between gap-3 bg-zinc-50">
          <div className="flex gap-2">
            <a href={`mailto:${inquiry.email}?subject=${encodeURIComponent('Your Ellis Island Events inquiry')}`} className="btn-primary !px-4 !py-2 !text-[11px]">
              <Mail className="w-3.5 h-3.5" /> Reply
            </a>
            {inquiry.phone && (
              <a href={`tel:${inquiry.phone}`} className="btn-outline !px-4 !py-2 !text-[11px]"><Phone className="w-3.5 h-3.5" /> Call</a>
            )}
          </div>
          {confirmDelete ? (
            <div className="flex items-center gap-2 text-sm">
              <span className="text-zinc-600">Delete permanently?</span>
              <button onClick={async () => { const ok = await onDelete(inquiry.id); if (!ok) setError('Could not delete inquiry.'); }} className="px-3 py-1.5 bg-red-600 text-white text-xs rounded hover:bg-red-700">Delete</button>
              <button onClick={() => setConfirmDelete(false)} className="px-3 py-1.5 text-xs text-zinc-600 hover:text-zinc-900">Cancel</button>
            </div>
          ) : (
            <button onClick={() => setConfirmDelete(true)} className="inline-flex items-center gap-1.5 text-xs text-zinc-500 hover:text-red-600">
              <Trash2 className="w-3.5 h-3.5" /> Delete inquiry
            </button>
          )}
        </footer>
      </aside>
    </div>
  );
}
