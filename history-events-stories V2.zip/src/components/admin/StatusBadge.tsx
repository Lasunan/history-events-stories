import { STATUS_STYLES, type InquiryStatus } from '@/lib/inquiries';

export default function StatusBadge({ status }: { status: InquiryStatus }) {
  const s = STATUS_STYLES[status] ?? STATUS_STYLES.New;
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset whitespace-nowrap ${s.badge}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${s.dot}`} />
      {status}
    </span>
  );
}
