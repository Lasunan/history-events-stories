import { Search, X } from 'lucide-react';
import { INQUIRY_EVENT_TYPES, VENUES } from '@/data/site';
import { INQUIRY_STATUSES, EMPTY_FILTERS, type InquiryFilters } from '@/lib/inquiries';

interface Props {
  filters: InquiryFilters;
  onChange: (f: InquiryFilters) => void;
}

const selectCls = 'h-10 bg-white border border-zinc-200 rounded-md px-3 text-sm text-zinc-800 focus:outline-none focus:ring-2 focus:ring-liberty-500/30 focus:border-liberty-500';

export default function InquiryFiltersBar({ filters, onChange }: Props) {
  const set = (k: keyof InquiryFilters) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    onChange({ ...filters, [k]: e.target.value });
  const active = Object.entries(filters).filter(([, v]) => v).length;

  return (
    <div className="bg-white border border-zinc-200 rounded-lg p-4 space-y-3">
      <div className="relative">
        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
        <input
          value={filters.search}
          onChange={set('search')}
          placeholder="Search name, email, phone, company or message…"
          className="w-full h-10 pl-9 pr-9 bg-zinc-50 border border-zinc-200 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-liberty-500/30 focus:border-liberty-500 focus:bg-white"
          aria-label="Search inquiries"
        />
        {filters.search && (
          <button onClick={() => onChange({ ...filters, search: '' })} className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-700" aria-label="Clear search">
            <X className="w-4 h-4" />
          </button>
        )}
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
        <select value={filters.status} onChange={set('status')} className={selectCls} aria-label="Filter by status">
          <option value="">All statuses</option>
          {INQUIRY_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <select value={filters.eventType} onChange={set('eventType')} className={selectCls} aria-label="Filter by event type">
          <option value="">All event types</option>
          {INQUIRY_EVENT_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
        </select>
        <select value={filters.venue} onChange={set('venue')} className={selectCls} aria-label="Filter by venue">
          <option value="">All venues</option>
          <option value="__none">No preference</option>
          {VENUES.map((v) => <option key={v.id} value={v.name}>{v.name}</option>)}
        </select>
        <label className="relative">
          <span className="absolute -top-2 left-2 bg-white px-1 text-[10px] text-zinc-500">Event date from</span>
          <input type="date" value={filters.dateFrom} onChange={set('dateFrom')} className={`${selectCls} w-full`} />
        </label>
        <label className="relative">
          <span className="absolute -top-2 left-2 bg-white px-1 text-[10px] text-zinc-500">Event date to</span>
          <input type="date" value={filters.dateTo} min={filters.dateFrom || undefined} onChange={set('dateTo')} className={`${selectCls} w-full`} />
        </label>
        <button
          onClick={() => onChange(EMPTY_FILTERS)}
          disabled={!active}
          className="h-10 rounded-md border border-zinc-200 text-sm text-zinc-600 hover:bg-zinc-50 disabled:opacity-40 inline-flex items-center justify-center gap-1.5"
        >
          <X className="w-4 h-4" /> Clear filters{active ? ` (${active})` : ''}
        </button>
      </div>
    </div>
  );
}
