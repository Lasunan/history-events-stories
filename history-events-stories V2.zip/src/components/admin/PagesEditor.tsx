import { useEffect, useMemo, useRef, useState } from 'react';
import {
  FileText, Save, RotateCcw, ExternalLink, Loader2, Check, AlertCircle, Upload, Eye, EyeOff, Image as ImageIcon, Search,
} from 'lucide-react';
import { IMG } from '@/data/site';
import { PAGE_DEFAULTS, PAGE_SLUGS, pagePath, type PageSlug, type SitePage } from '@/data/pages';
import { fetchPages, savePage, uploadSiteImage, useInvalidatePages } from '@/lib/pages';
import { fmtDate } from '@/lib/inquiries';
import RichText from '@/components/site/RichText';

const IMAGE_CHOICES = Array.from(new Set(Object.entries(IMG).filter(([k]) => !['logo', 'medallion95', 'patti', 'tara'].includes(k)).map(([, v]) => v)));

const Field = ({ label, hint, children }: { label: string; hint?: React.ReactNode; children: React.ReactNode }) => (
  <label className="block">
    <span className="flex items-center justify-between text-xs font-medium text-zinc-600 mb-1.5">{label}{hint && <span className="font-normal text-zinc-400">{hint}</span>}</span>
    {children}
  </label>
);
const inputCls = 'w-full rounded-md border border-zinc-200 bg-white px-3 py-2 text-sm text-zinc-900 focus:outline-none focus:ring-2 focus:ring-liberty-500/40 focus:border-liberty-500';

export default function PagesEditor({ email }: { email: string }) {
  const [pages, setPages] = useState<Record<PageSlug, SitePage> | null>(null);
  const [slug, setSlug] = useState<PageSlug>('home');
  const [draft, setDraft] = useState<SitePage>(PAGE_DEFAULTS.home);
  const [status, setStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const [uploading, setUploading] = useState(false);
  const [msg, setMsg] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);
  const invalidate = useInvalidatePages();

  useEffect(() => {
    fetchPages().then((p) => { setPages(p); setDraft(p.home); });
  }, []);

  const saved = pages?.[slug];
  const dirty = useMemo(() => !!saved && JSON.stringify({ ...saved, updated_at: 0, updated_by: 0 }) !== JSON.stringify({ ...draft, updated_at: 0, updated_by: 0 }), [saved, draft]);

  const select = (s: PageSlug) => {
    if (dirty && !window.confirm('You have unsaved changes. Discard them?')) return;
    setSlug(s);
    if (pages) setDraft(pages[s]);
    setStatus('idle'); setMsg('');
  };

  const set = <K extends keyof SitePage>(k: K, v: SitePage[K]) => { setDraft((d) => ({ ...d, [k]: v })); setStatus('idle'); };

  const save = async () => {
    if (!draft.hero_title.trim() || !draft.nav_label.trim()) { setStatus('error'); setMsg('Navigation label and headline are required.'); return; }
    setStatus('saving'); setMsg('');
    const { data, error } = await savePage(draft, email);
    if (error) { setStatus('error'); setMsg(error.message || 'Could not save. Make sure you are signed in as an admin.'); return; }
    const updated = { ...draft, updated_at: (data as SitePage)?.updated_at ?? new Date().toISOString(), updated_by: email };
    setPages((p) => (p ? { ...p, [slug]: updated } : p));
    setDraft(updated);
    invalidate();
    setStatus('saved');
    setTimeout(() => setStatus((s) => (s === 'saved' ? 'idle' : s)), 2500);
  };

  const onUpload = async (file?: File) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) { setMsg('Please choose an image file.'); return; }
    if (file.size > 8 * 1024 * 1024) { setMsg('Image must be under 8 MB.'); return; }
    setUploading(true); setMsg('');
    try { set('hero_image', await uploadSiteImage(file)); }
    catch (e) { setMsg((e as Error).message || 'Upload failed.'); }
    finally { setUploading(false); if (fileRef.current) fileRef.current.value = ''; }
  };

  if (!pages) return <div className="py-24 flex justify-center"><Loader2 className="w-6 h-6 animate-spin text-zinc-400" /></div>;

  const path = pagePath(slug);
  const seoTitleLen = draft.seo_title.length;
  const metaLen = draft.meta_description.length;

  return (
    <div className="grid lg:grid-cols-[260px_1fr] gap-6">
      {/* Page list */}
      <aside className="bg-white border border-zinc-200 rounded-lg overflow-hidden h-fit lg:sticky lg:top-24">
        <div className="px-4 py-3 border-b border-zinc-100 text-xs uppercase tracking-wider text-zinc-500">Site Pages</div>
        <ul>
          {PAGE_SLUGS.map((s) => {
            const p = pages[s];
            return (
              <li key={s}>
                <button onClick={() => select(s)} className={`w-full text-left px-4 py-3 flex items-start gap-3 border-l-2 transition ${slug === s ? 'bg-liberty-50 border-liberty-600' : 'border-transparent hover:bg-zinc-50'}`}>
                  <FileText className={`w-4 h-4 mt-0.5 ${slug === s ? 'text-liberty-700' : 'text-zinc-400'}`} />
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-medium text-zinc-900 flex items-center gap-2">
                      {p.nav_label}
                      {!p.published && <span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-100 text-zinc-500">Hidden</span>}
                    </div>
                    <div className="text-xs text-zinc-400 font-mono">{pagePath(s)}</div>
                  </div>
                </button>
              </li>
            );
          })}
        </ul>
      </aside>

      <div className="space-y-6 min-w-0">
        {/* Toolbar */}
        <div className="bg-white border border-zinc-200 rounded-lg px-4 py-3 flex flex-wrap items-center gap-3 justify-between">
          <div className="min-w-0">
            <div className="font-serif text-xl text-zinc-900">{draft.nav_label} <span className="font-mono text-sm text-zinc-400">{path}</span></div>
            <div className="text-xs text-zinc-500">{saved?.updated_at ? `Last edited ${fmtDate(saved.updated_at, true)}${saved.updated_by ? ` by ${saved.updated_by}` : ''}` : 'Using default content'}{dirty && <span className="ml-2 text-amber-600 font-medium">· Unsaved changes</span>}</div>
          </div>
          <div className="flex items-center gap-2">
            <a href={path} target="_blank" rel="noopener noreferrer" className="h-9 px-3 inline-flex items-center gap-1.5 rounded-md border border-zinc-200 text-sm text-zinc-700 hover:bg-zinc-50"><ExternalLink className="w-4 h-4" /> View</a>
            <button onClick={() => { setDraft(saved!); setStatus('idle'); setMsg(''); }} disabled={!dirty} className="h-9 px-3 inline-flex items-center gap-1.5 rounded-md border border-zinc-200 text-sm text-zinc-700 hover:bg-zinc-50 disabled:opacity-40"><RotateCcw className="w-4 h-4" /> Discard</button>
            <button onClick={save} disabled={status === 'saving' || !dirty} className="h-9 px-4 inline-flex items-center gap-1.5 rounded-md bg-liberty-600 text-white text-sm hover:bg-liberty-700 disabled:opacity-50">
              {status === 'saving' ? <Loader2 className="w-4 h-4 animate-spin" /> : status === 'saved' ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
              {status === 'saved' ? 'Published' : 'Save & Publish'}
            </button>
          </div>
        </div>
        {msg && <div className="flex items-center gap-2 text-sm text-red-700 bg-red-50 border border-red-200 rounded-md px-4 py-3"><AlertCircle className="w-4 h-4" /> {msg}</div>}

        <div className="grid xl:grid-cols-2 gap-6">
          {/* Form */}
          <div className="space-y-6">
            <section className="bg-white border border-zinc-200 rounded-lg p-5 space-y-4">
              <h3 className="text-sm font-semibold text-zinc-900">Navigation</h3>
              <div className="grid sm:grid-cols-[1fr_110px] gap-4">
                <Field label="Menu label"><input className={inputCls} value={draft.nav_label} onChange={(e) => set('nav_label', e.target.value)} /></Field>
                <Field label="Menu order"><input type="number" className={inputCls} value={draft.sort_order} onChange={(e) => set('sort_order', Number(e.target.value) || 0)} /></Field>
              </div>
              <div className="flex flex-wrap gap-5 text-sm text-zinc-700">
                <label className="inline-flex items-center gap-2 cursor-pointer"><input type="checkbox" className="accent-liberty-600" checked={draft.show_in_nav} disabled={slug === 'home'} onChange={(e) => set('show_in_nav', e.target.checked)} /> Show in top menu</label>
                <label className="inline-flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" className="accent-liberty-600" checked={draft.published} disabled={slug === 'home'} onChange={(e) => set('published', e.target.checked)} />
                  {draft.published ? <><Eye className="w-4 h-4" /> Published</> : <><EyeOff className="w-4 h-4" /> Hidden from public</>}
                </label>
              </div>
            </section>

            <section className="bg-white border border-zinc-200 rounded-lg p-5 space-y-4">
              <h3 className="text-sm font-semibold text-zinc-900">Hero Banner</h3>
              <Field label="Eyebrow (small text above headline)"><input className={inputCls} value={draft.hero_eyebrow} onChange={(e) => set('hero_eyebrow', e.target.value)} /></Field>
              <Field label="Headline *"><input className={inputCls} value={draft.hero_title} onChange={(e) => set('hero_title', e.target.value)} /></Field>
              <Field label="Subheading"><textarea rows={3} className={`${inputCls} resize-y`} value={draft.hero_subtitle} onChange={(e) => set('hero_subtitle', e.target.value)} /></Field>
              <Field label="Background image" hint="Upload or pick below">
                <div className="flex gap-2">
                  <input className={inputCls} value={draft.hero_image} onChange={(e) => set('hero_image', e.target.value)} placeholder="https://…" />
                  <button type="button" onClick={() => fileRef.current?.click()} disabled={uploading} className="shrink-0 h-[38px] px-3 inline-flex items-center gap-1.5 rounded-md border border-zinc-200 text-sm text-zinc-700 hover:bg-zinc-50 disabled:opacity-50">
                    {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />} Upload
                  </button>
                  <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => onUpload(e.target.files?.[0])} />
                </div>
              </Field>
              <div className="grid grid-cols-6 sm:grid-cols-8 gap-1.5">
                {IMAGE_CHOICES.map((src) => (
                  <button key={src} type="button" onClick={() => set('hero_image', src)} className={`aspect-square overflow-hidden rounded ring-offset-1 ${draft.hero_image === src ? 'ring-2 ring-liberty-600' : 'hover:opacity-80'}`} aria-label="Use this image">
                    <img src={src} alt="" loading="lazy" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            </section>

            <section className="bg-white border border-zinc-200 rounded-lg p-5 space-y-3">
              <h3 className="text-sm font-semibold text-zinc-900">Page Introduction <span className="font-normal text-zinc-400">(optional, shown below the banner)</span></h3>
              <textarea rows={8} className={`${inputCls} font-mono text-[13px] resize-y`} value={draft.body} onChange={(e) => set('body', e.target.value)} placeholder={'Write a paragraph…\n\n## A subheading\n\n- A bullet point\n- **Bold text** and [a link](/venues)'} />
              <p className="text-xs text-zinc-400">Blank line = new paragraph · <code>## </code> heading · <code>- </code> bullet · <code>**bold**</code> · <code>[text](/page)</code> link</p>
            </section>

            <section className="bg-white border border-zinc-200 rounded-lg p-5 space-y-4">
              <h3 className="text-sm font-semibold text-zinc-900 flex items-center gap-2"><Search className="w-4 h-4 text-zinc-400" /> Search Engine (SEO)</h3>
              <Field label="Page title" hint={<span className={seoTitleLen > 60 ? 'text-amber-600' : ''}>{seoTitleLen}/60</span>}><input className={inputCls} value={draft.seo_title} onChange={(e) => set('seo_title', e.target.value)} /></Field>
              <Field label="Meta description" hint={<span className={metaLen > 160 ? 'text-amber-600' : ''}>{metaLen}/160</span>}><textarea rows={3} className={`${inputCls} resize-y`} value={draft.meta_description} onChange={(e) => set('meta_description', e.target.value)} /></Field>
              <div className="rounded-md bg-zinc-50 border border-zinc-100 p-3">
                <div className="text-xs text-emerald-700">ellisisland-events.com{path === '/' ? '' : path}</div>
                <div className="text-[#1a0dab] text-base leading-snug truncate">{draft.seo_title || draft.hero_title}</div>
                <div className="text-xs text-zinc-600 line-clamp-2">{draft.meta_description}</div>
              </div>
            </section>
          </div>

          {/* Live preview */}
          <div className="xl:sticky xl:top-24 h-fit space-y-3">
            <div className="text-xs uppercase tracking-wider text-zinc-500 flex items-center gap-2"><ImageIcon className="w-3.5 h-3.5" /> Live preview</div>
            <div className="rounded-lg overflow-hidden border border-zinc-200 shadow-sm bg-white">
              <div className="relative aspect-[16/10] bg-charcoal">
                {draft.hero_image && <img src={draft.hero_image} alt="" className="absolute inset-0 w-full h-full object-cover" />}
                <div className="absolute inset-0 bg-gradient-to-br from-liberty-900/85 via-charcoal/55 to-charcoal/90" />
                <div className="relative h-full flex flex-col justify-end p-6">
                  <div className="font-serif text-liberty-200 text-[10px] tracking-[0.3em] uppercase">{draft.hero_eyebrow}</div>
                  <div className="font-serif text-white text-2xl leading-tight mt-2">{draft.hero_title}</div>
                  {draft.hero_subtitle && <p className="font-display text-white/80 text-sm mt-2 line-clamp-3">{draft.hero_subtitle}</p>}
                </div>
              </div>
              {draft.body.trim() && <div className="p-5 max-h-72 overflow-auto"><RichText text={draft.body} className="!text-sm" /></div>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
