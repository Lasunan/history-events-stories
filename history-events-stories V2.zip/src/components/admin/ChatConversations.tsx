import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  MessageSquare, Search, RefreshCw, Loader2, Trash2, Mail, Phone, CalendarDays, Users, PartyPopper,
  MapPin, Building2, CheckCircle2, ExternalLink, Download, Bot, Inbox, AlertCircle,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { fmtDate } from '@/lib/inquiries';
import { CHAT_ASSISTANT, CHAT_STATUSES, type ChatConversation, type ChatStatus } from '@/lib/chat';
import ChatMessageContent from '@/components/chat/ChatMessageContent';

type Filter = 'all' | 'leads' | ChatStatus;

const csvCell = (v: unknown) => {
  const s = v === null || v === undefined ? '' : String(v);
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

function exportChatsCsv(list: ChatConversation[]) {
  const headers = ['Started', 'Last Message', 'Status', 'Lead Captured', 'Name', 'Email', 'Phone', 'SMS Opt-In', 'Company', 'Event Type', 'Venue', 'Event Date', 'Guests', 'Messages', 'Page', 'Transcript'];
  const rows = list.map((c) => [
    c.created_at, c.updated_at, c.status, c.lead_captured ? 'Yes' : 'No', c.visitor_name, c.visitor_email, c.visitor_phone,
    c.sms_opt_in ? 'Yes' : 'No', c.company, c.event_type, c.venue, c.event_date, c.guest_count, c.message_count, c.page_path,
    (c.messages || []).map((m) => `${m.role === 'user' ? 'Visitor' : 'AI'}: ${m.content}`).join(' | '),
  ]);
  const csv = [headers, ...rows].map((r) => r.map(csvCell).join(',')).join('\r\n');
  const url = URL.createObjectURL(new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' }));
  const a = document.createElement('a');
  a.href = url;
  a.download = `ellis-island-ai-chats-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export default function ChatConversations({ onOpenInquiry }: { onOpenInquiry: (id: string) => void }) {
  const [chats, setChats] = useState<ChatConversation[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<Filter>('all');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    const { data, error } = await supabase.from('chat_conversations').select('*').order('updated_at', { ascending: false }).limit(500);
    if (error) setError('Could not load conversations. Please refresh.');
    const list = (data as ChatConversation[]) || [];
    setChats(list);
    setSelectedId((id) => id && list.some((c) => c.id === id) ? id : list[0]?.id ?? null);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);
  useEffect(() => setConfirmDelete(false), [selectedId]);

  const stats = useMemo(() => {
    const weekAgo = Date.now() - 7 * 864e5;
    const leads = chats.filter((c) => c.lead_captured).length;
    return {
      total: chats.length,
      leads,
      emails: chats.filter((c) => c.visitor_email).length,
      week: chats.filter((c) => new Date(c.created_at).getTime() > weekAgo).length,
      rate: chats.length ? Math.round((leads / chats.length) * 100) : 0,
    };
  }, [chats]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return chats.filter((c) => {
      if (filter === 'leads' && !c.lead_captured) return false;
      if (filter !== 'all' && filter !== 'leads' && c.status !== filter) return false;
      if (!q) return true;
      const hay = [c.visitor_name, c.visitor_email, c.visitor_phone, c.company, c.event_type, c.venue, ...(c.messages || []).map((m) => m.content)]
        .filter(Boolean).join(' ').toLowerCase();
      return hay.includes(q);
    });
  }, [chats, search, filter]);

  const selected = chats.find((c) => c.id === selectedId) || null;

  const updateStatus = async (status: ChatStatus) => {
    if (!selected) return;
    const prev = chats;
    setChats((l) => l.map((c) => (c.id === selected.id ? { ...c, status } : c)));
    const { error } = await supabase.from('chat_conversations').update({ status }).eq('id', selected.id);
    if (error) setChats(prev);
  };

  const remove = async () => {
    if (!selected) return;
    const { error } = await supabase.from('chat_conversations').delete().eq('id', selected.id);
    if (!error) {
      const rest = chats.filter((c) => c.id !== selected.id);
      setChats(rest);
      setSelectedId(rest[0]?.id ?? null);
    }
  };

  const firstQuestion = (c: ChatConversation) => c.messages?.find((m) => m.role === 'user')?.content || 'No visitor messages yet';

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-serif text-2xl sm:text-3xl text-zinc-900 flex items-center gap-3">
            <img src={CHAT_ASSISTANT.avatar} alt="" className="w-9 h-9 rounded-full object-cover ring-2 ring-liberty-400" /> AI Concierge Chats
          </h1>
          <p className="text-sm text-zinc-500 mt-1">Every website chat with the AI concierge. Qualified leads are automatically added to Inquiries and the CRM.</p>
        </div>
        <div className="flex gap-2">
          <button onClick={load} disabled={loading} className="h-10 px-4 inline-flex items-center gap-2 rounded-md border border-zinc-200 bg-white text-sm text-zinc-700 hover:bg-zinc-50 disabled:opacity-50">
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /> Refresh
          </button>
          <button onClick={() => exportChatsCsv(filtered)} disabled={!filtered.length} className="h-10 px-4 inline-flex items-center gap-2 rounded-md bg-liberty-600 text-white text-sm hover:bg-liberty-700 disabled:opacity-50">
            <Download className="w-4 h-4" /> Export CSV
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: 'Conversations', value: stats.total, icon: MessageSquare },
          { label: 'Leads captured', value: stats.leads, icon: CheckCircle2 },
          { label: 'Lead conversion', value: `${stats.rate}%`, icon: Bot },
          { label: 'Last 7 days', value: stats.week, icon: CalendarDays },
        ].map((s) => (
          <div key={s.label} className="bg-white rounded-lg border border-zinc-200 p-4">
            <div className="flex items-center gap-2 text-xs text-zinc-500"><s.icon className="w-3.5 h-3.5" /> {s.label}</div>
            <div className="text-2xl font-semibold text-zinc-900 mt-1">{s.value}</div>
          </div>
        ))}
      </div>

      {error && (
        <div className="flex items-center gap-2 text-sm text-red-700 bg-red-50 border border-red-200 rounded-md px-4 py-3"><AlertCircle className="w-4 h-4" /> {error}</div>
      )}

      <div className="grid lg:grid-cols-[380px_1fr] gap-4 min-h-[600px]">
        {/* List */}
        <div className="bg-white border border-zinc-200 rounded-lg flex flex-col overflow-hidden">
          <div className="p-3 border-b border-zinc-200 space-y-2">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
              <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search name, email, message…" className="w-full h-9 pl-9 pr-3 rounded-md border border-zinc-200 text-sm focus:outline-none focus:ring-2 focus:ring-liberty-500/30" />
            </div>
            <div className="flex flex-wrap gap-1">
              {(['all', 'leads', ...CHAT_STATUSES] as Filter[]).map((f) => (
                <button key={f} onClick={() => setFilter(f)} className={`px-2.5 py-1 rounded text-xs capitalize ${filter === f ? 'bg-charcoal text-white' : 'bg-zinc-100 text-zinc-600 hover:bg-zinc-200'}`}>
                  {f === 'leads' ? `Leads (${stats.leads})` : f}
                </button>
              ))}
            </div>
          </div>
          <div className="flex-1 overflow-y-auto divide-y divide-zinc-100 max-h-[720px]">
            {loading && !chats.length ? (
              <div className="py-16 text-center text-zinc-400"><Loader2 className="w-6 h-6 animate-spin mx-auto" /></div>
            ) : filtered.length === 0 ? (
              <div className="py-16 px-6 text-center">
                <Inbox className="w-10 h-10 text-zinc-300 mx-auto" />
                <p className="mt-3 text-sm text-zinc-500">{chats.length ? 'No chats match these filters.' : 'No chats yet. Conversations from the website concierge will appear here.'}</p>
              </div>
            ) : (
              filtered.map((c) => (
                <button key={c.id} onClick={() => setSelectedId(c.id)} className={`w-full text-left px-4 py-3 transition ${selectedId === c.id ? 'bg-liberty-50' : 'hover:bg-zinc-50'}`}>
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-medium text-sm text-zinc-900 truncate">{c.visitor_name || c.visitor_email || 'Anonymous visitor'}</span>
                    <span className="text-[11px] text-zinc-400 shrink-0">{fmtDate(c.updated_at, true)}</span>
                  </div>
                  <p className="text-xs text-zinc-500 truncate mt-0.5">{firstQuestion(c)}</p>
                  <div className="flex items-center gap-2 mt-1.5">
                    {c.lead_captured && <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200">Lead</span>}
                    {!c.lead_captured && c.visitor_email && <span className="text-[10px] px-1.5 py-0.5 rounded bg-sky-50 text-sky-700 ring-1 ring-sky-200">Email</span>}
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-100 text-zinc-600">{c.status}</span>
                    <span className="text-[10px] text-zinc-400 ml-auto">{c.message_count} msgs</span>
                  </div>
                </button>
              ))
            )}
          </div>
        </div>

        {/* Detail */}
        <div className="bg-white border border-zinc-200 rounded-lg overflow-hidden flex flex-col">
          {!selected ? (
            <div className="flex-1 flex items-center justify-center text-zinc-400 text-sm p-10">Select a conversation to view the transcript.</div>
          ) : (
            <>
              <div className="p-5 border-b border-zinc-200">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <h2 className="font-serif text-xl text-zinc-900">{selected.visitor_name || 'Anonymous visitor'}</h2>
                    <p className="text-xs text-zinc-500 mt-0.5">Started {fmtDate(selected.created_at, true)}{selected.page_path ? ` · on ${selected.page_path}` : ''}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <select value={selected.status} onChange={(e) => updateStatus(e.target.value as ChatStatus)} className="h-9 rounded-md border border-zinc-200 text-sm px-2 bg-white" aria-label="Conversation status">
                      {CHAT_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                    {confirmDelete ? (
                      <>
                        <button onClick={remove} className="h-9 px-3 rounded-md bg-red-600 text-white text-sm hover:bg-red-700">Confirm delete</button>
                        <button onClick={() => setConfirmDelete(false)} className="h-9 px-3 rounded-md border border-zinc-200 text-sm">Cancel</button>
                      </>
                    ) : (
                      <button onClick={() => setConfirmDelete(true)} className="h-9 w-9 inline-flex items-center justify-center rounded-md border border-zinc-200 text-zinc-500 hover:text-red-600 hover:border-red-200" aria-label="Delete conversation"><Trash2 className="w-4 h-4" /></button>
                    )}
                  </div>
                </div>
                <dl className="mt-4 grid sm:grid-cols-2 xl:grid-cols-3 gap-x-6 gap-y-2 text-sm">
                  {[
                    [Mail, selected.visitor_email && <a href={`mailto:${selected.visitor_email}`} className="text-liberty-700 hover:underline">{selected.visitor_email}</a>],
                    [Phone, selected.visitor_phone && <a href={`tel:${selected.visitor_phone}`} className="text-liberty-700 hover:underline">{selected.visitor_phone}{selected.sms_opt_in ? ' (SMS ok)' : ''}</a>],
                    [Building2, selected.company],
                    [PartyPopper, selected.event_type],
                    [CalendarDays, selected.event_date && fmtDate(selected.event_date)],
                    [Users, selected.guest_count && `${selected.guest_count.toLocaleString()} guests`],
                    [MapPin, selected.venue],
                  ].map(([I, v], idx) => {
                    const Icon = I as typeof Mail;
                    return (
                      <div key={idx} className="flex items-center gap-2 min-w-0">
                        <Icon className="w-4 h-4 text-zinc-400 shrink-0" />
                        <span className={`truncate ${v ? 'text-zinc-800' : 'text-zinc-300'}`}>{(v as React.ReactNode) || '—'}</span>
                      </div>
                    );
                  })}
                </dl>
                {selected.inquiry_id && (
                  <button onClick={() => onOpenInquiry(selected.inquiry_id!)} className="mt-4 inline-flex items-center gap-2 text-sm px-3 py-2 rounded-md bg-emerald-50 text-emerald-800 ring-1 ring-emerald-200 hover:bg-emerald-100">
                    <CheckCircle2 className="w-4 h-4" /> Lead saved to Inquiries — open inquiry <ExternalLink className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
              <div className="flex-1 overflow-y-auto bg-zinc-50 p-5 space-y-3 max-h-[560px]">
                {(selected.messages || []).map((m, i) => (
                  <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'gap-2 items-end'}`}>
                    {m.role === 'assistant' && <img src={CHAT_ASSISTANT.avatar} alt="" className="w-6 h-6 rounded-full object-cover shrink-0" />}
                    <div className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${m.role === 'user' ? 'bg-liberty-700 text-white rounded-br-sm whitespace-pre-wrap' : 'bg-white border border-zinc-200 text-zinc-800 rounded-bl-sm'}`}>
                      {m.role === 'assistant' ? <ChatMessageContent text={m.content} /> : m.content}
                      {m.at && <div className={`text-[10px] mt-1 ${m.role === 'user' ? 'text-white/60' : 'text-zinc-400'}`}>{new Date(m.at).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}</div>}
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
