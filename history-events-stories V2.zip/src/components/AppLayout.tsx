import { useCallback, useEffect, useMemo } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import Navbar from './site/Navbar';
import Hero from './site/Hero';
import PageHero from './site/PageHero';
import CtaBand from './site/CtaBand';
import Intro from './site/Intro';
import Venues from './site/Venues';
import EventTypes from './site/EventTypes';
import Gallery from './site/Gallery';
import About from './site/About';
import Testimonials from './site/Testimonials';
import Tours from './site/Tours';
import Faq from './site/Faq';
import InquiryForm, { type InquiryPreset } from './site/InquiryForm';
import Footer from './site/Footer';
import RichText from './site/RichText';
import ChatWidget from './chat/ChatWidget';
import { useReveal } from '@/hooks/useReveal';
import { usePage, useSeo } from '@/lib/pages';
import type { PageSlug } from '@/data/pages';

export default function AppLayout({ slug }: { slug: PageSlug }) {
  const page = usePage(slug);
  const navigate = useNavigate();
  const location = useLocation();
  useSeo(page);
  useReveal([slug, page.updated_at]);

  // Scroll to top on every route change.
  useEffect(() => { window.scrollTo({ top: 0, behavior: 'auto' }); }, [slug]);

  const goToInquiry = useCallback(
    (p: Omit<InquiryPreset, 'nonce'>) => navigate('/inquire', { state: { ...p, nonce: Date.now() } }),
    [navigate]
  );

  const preset = useMemo<InquiryPreset>(() => {
    const s = (location.state || {}) as Partial<InquiryPreset>;
    return { venue: s.venue, eventType: s.eventType, nonce: s.nonce || 0 };
  }, [location.state]);

  const NextStep = ({ to, label }: { to: string; label: string }) => (
    <div className="bg-ivory border-t border-charcoal/5">
      <div className="max-w-7xl mx-auto px-5 lg:px-8 py-10 flex flex-col sm:flex-row items-center justify-between gap-4">
        <p className="font-display text-xl text-charcoal/70">Continue exploring</p>
        <Link to={to} className="inline-flex items-center gap-2 font-serif text-sm tracking-[0.2em] uppercase text-liberty-700 hover:text-liberty-900">
          {label} <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );

  let content: React.ReactNode;
  if (!page.published) {
    content = (
      <>
        <PageHero page={{ ...page, body: '' }} />
        <section className="py-24 text-center">
          <p className="text-charcoal/70">This page is not currently available.</p>
          <Link to="/" className="btn-primary mt-6">Return Home</Link>
        </section>
      </>
    );
  } else {
    switch (slug) {
      case 'home':
        content = (
          <>
            <Hero page={page} />
            {page.body.trim() && (
              <section className="bg-white py-16"><div className="max-w-3xl mx-auto px-5 lg:px-8"><RichText text={page.body} /></div></section>
            )}
            <Intro />
            <Venues onRequest={(venue) => goToInquiry({ venue })} />
            <EventTypes onSelect={(eventType) => goToInquiry({ eventType })} />
            <Gallery />
            <CtaBand />
            <About />
            <Testimonials />
            <Tours />
            <Faq />
            <InquiryForm preset={preset} />
          </>
        );
        break;
      case 'venues':
        content = (<><PageHero page={page} /><Venues onRequest={(venue) => goToInquiry({ venue })} /><CtaBand /><NextStep to="/events" label="Event Types" /></>);
        break;
      case 'events':
        content = (<><PageHero page={page} /><EventTypes onSelect={(eventType) => goToInquiry({ eventType })} /><Testimonials /><CtaBand /><NextStep to="/gallery" label="Gallery" /></>);
        break;
      case 'gallery':
        content = (<><PageHero page={page} /><Gallery /><CtaBand /><NextStep to="/venues" label="Explore Venues" /></>);
        break;
      case 'about':
        content = (<><PageHero page={page} /><Intro /><About /><Testimonials /><NextStep to="/tours" label="Virtual Tours" /></>);
        break;
      case 'tours':
        content = (<><PageHero page={page} /><Tours /><CtaBand /><NextStep to="/faq" label="Planning FAQ" /></>);
        break;
      case 'faq':
        content = (<><PageHero page={page} /><Faq /><CtaBand /></>);
        break;
      case 'inquire':
        content = (<><PageHero page={page} /><InquiryForm preset={preset} /><Faq /></>);
        break;
    }
  }

  return (
    <div className="min-h-screen bg-ivory">
      <Navbar />
      <main>{content}</main>
      <Footer onVenue={(venue) => goToInquiry({ venue })} />
      <ChatWidget />
    </div>
  );
}
