import { Fragment } from 'react';
import { inline } from '@/components/site/RichText';

export default function ChatMessageContent({ text }: { text: string }) {
  const blocks = text.replace(/\r\n/g, '\n').split(/\n{2,}/).map((b) => b.trim()).filter(Boolean);
  return (
    <div className="space-y-2">
      {blocks.map((b, idx) => {
        const lines = b.split('\n');
        if (lines.every((l) => /^\s*[-*•] /.test(l))) {
          return (
            <ul key={idx} className="space-y-1">
              {lines.map((l, j) => (
                <li key={j} className="flex gap-2">
                  <span className="mt-[7px] w-1.5 h-1.5 rounded-full bg-liberty-500 shrink-0" />
                  <span>{inline(l.replace(/^\s*[-*•] /, ''))}</span>
                </li>
              ))}
            </ul>
          );
        }
        return (
          <p key={idx}>
            {lines.map((l, j) => (
              <Fragment key={j}>{j > 0 && <br />}{/^\s*[-*•] /.test(l) && '• '}{inline(l.replace(/^\s*[-*•] /, ''))}</Fragment>
            ))}
          </p>
        );
      })}
    </div>
  );
}
