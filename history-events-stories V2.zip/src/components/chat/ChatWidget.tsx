import { useCallback, useEffect, useRef, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { X, Send, RotateCcw, Phone, CalendarCheck, Sparkles, CheckCircle2, ChevronDown, Users, CalendarDays, PartyPopper, FileText, MessageCircle } from 'lucide-react';
import { CONTACT, PATTI_PHONE, RFQ_PATH } from '@/data/site';
import { fmtDate } from '@/lib/inquiries';
import {
  CHAT_ASSISTANT, askConcierge, createInquiryFromLead, freshChatState, leadIsQualified, loadChatState,
  mergeLead, persistTranscript, saveChatState, syncCrm, type ChatMessage, type ChatState,
} from '@/lib/chat';
import { isValidEmail } from '@/lib/crm';
import { OPEN_CHAT_EVENT } from '@/lib/chatEvents';
import ChatMessageContent from './ChatMessageContent';

const TEASER_KEY = 'eie-chat-teaser-dismissed';

export default function ChatWidget() {
  const { pathname } = useLocation();
  const [open, setOpen] = useState(() => {
    try { return sessionStorage.getItem('eie-chat-open') === '1'; } catch { return false; }
  });
  const [state, setState] = useState<ChatState>(() => loadChatState());
  const [input, setInput] = useState('');
  useEffect(() => { try { sessionStorage.setItem('eie-chat-open', open ? '1' : '0'); } catch { /* ignore */ } }, [open]);
  // On small screens the panel is full-screen, so close it when a chat link navigates to another page.
  const lastPath = useRef(pathname);
  useEffect(() => {
    if (pathname !== lastPath.current && window.innerWidth < 640) setOpen(false);
    lastPath.current = pathname;
  }, [pathname]);
  const [loading, setLoading] = useState(false);
  const [teaser, setTeaser] = useState(false);
  const stateRef = useRef(state);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const crmKeyRef = useRef<string>('');

  useEffect(() => { stateRef.current = state; saveChatState(state); }, [state]);

  // Gentle teaser bubble after a few seconds (once per browser session).
  useEffect(() => {
    if (sessionStorage.getItem(TEASER_KEY)) return;
    const t = setTimeout(() => setTeaser(true), 7000);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    if (open) {
      setTeaser(false);
      sessionStorage.setItem(TEASER_KEY, '1');
      setTimeout(() => inputRef.current?.focus(), 150);
    }
  }, [open]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [state.messages.length, loading, open]);

  // Close on Escape
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const send = useCallback(async (raw: string) => {
    const text = raw.trim();
    if (!text || loading) return;
    const userMsg: ChatMessage = { role: 'user', content: text, at: new Date().toISOString() };
    const base = stateRef.current;
    const messages = [...base.messages, userMsg];
    setState({ ...base, messages, suggestions: [] });
    setInput('');
    setLoading(true);

    let next: ChatState;
    try {
      const res = await askConcierge(messages, base.lead, pathname);
      const lead = mergeLead(base.lead, res.lead);
      next = {
        ...base,
        messages: [...messages, { role: 'assistant', content: res.reply, at: new Date().toISOString() }],
        lead,
        suggestions: res.suggestions || [],
      };

      // CRM: subscribe as soon as a valid email is known; re-sync if phone / SMS consent changes.
      if (lead.email && isValidEmail(lead.email)) {
        const key = `${lead.email}|${lead.phone || ''}|${lead.sms_opt_in ? 1 : 0}|${lead.first_name || ''}`;
        if (key !== crmKeyRef.current) {
          crmKeyRef.current = key;
          syncCrm(lead).catch((e) => console.error('CRM sync failed', e));
          next.subscribedEmail = lead.email;
        }
      }

      // Inquiry: create once we have name + email + date or guest count.
      if (!next.inquiryId && leadIsQualified(lead)) {
        next.inquiryId = await createInquiryFromLead(lead, next.messages);
      }
    } catch (e) {
      console.error(e);
      next = {
        ...base,
        messages: [
          ...messages,
          {
            role: 'assistant',
            content: `I'm having trouble connecting right now. Please try again in a moment, fill out our [Request a Quote form](${RFQ_PATH}), or call Patti directly at **${PATTI_PHONE.display}**.`,
            at: new Date().toISOString(),
          },
        ],
        suggestions: [],
      };
    }
    setState(next);
    setLoading(false);
    persistTranscript(next, pathname);
  }, [loading, pathname]);

  // Allow other buttons on the site to open the chat (optionally with a prompt).
  useEffect(() => {
    const handler = (e: Event) => {
      const prompt = (e as CustomEvent<{ prompt?: string }>).detail?.prompt;
      setOpen(true);
      if (prompt) setTimeout(() => send(prompt), 250);
    };
    window.addEventListener(OPEN_CHAT_EVENT, handler);
    return () => window.removeEventListener(OPEN_CHAT_EVENT, handler);
  }, [send]);

  const restart = () => {
    crmKeyRef.current = '';
    setState(freshChatState());
    setInput('');
  };

  const { lead } = state;
  const hasEventInfo = !!(lead.event_type || lead.event_date || lead.guest_count);

  return (
    <>
      {/* Launcher */}
      <div className={`fixed bottom-5 right-5 z-[60] flex items-end gap-3 transition-all duration-300 ${open ? 'opacity-0 pointer-events-none translate-y-4' : 'opacity-100'}`}>
        {teaser && (
          <div className="hidden sm:block relative max-w-[260px] bg-white shadow-2xl border border-charcoal/10 p-4 pr-8 animate-in fade-in slide-in-from-bottom-2">
            <button onClick={() => { setTeaser(false); sessionStorage.setItem(TEASER_KEY, '1'); }} className="absolute top-2 right-2 text-charcoal/40 hover:text-charcoal" aria-label="Dismiss">
              <X className="w-3.5 h-3.5" />
            </button>
            <p className="text-sm text-charcoal/80 leading-snug">
              Planning an event at Ellis or Liberty Island? <button onClick={() => setOpen(true)} className="text-liberty-700 font-semibold hover:underline">Ask me anything</button>
            </p>
          </div>
        )}
        <button
          onClick={() => setOpen(true)}
          className="group flex items-center gap-3 bg-charcoal text-white pl-1.5 pr-5 py-1.5 rounded-full shadow-2xl ring-1 ring-white/10 hover:bg-liberty-800 transition"
          aria-label="Open AI event concierge chat"
        >
          <span className="relative">
            <img src={CHAT_ASSISTANT.avatar} alt="" className="w-12 h-12 rounded-full object-cover ring-2 ring-liberty-400" />
            <span className="absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full bg-emerald-400 ring-2 ring-charcoal" />
          </span>
          <span className="text-left hidden sm:block">
            <span className="block text-sm font-semibold leading-tight">Ask Patti's AI Concierge</span>
            <span className="block text-[11px] text-white/60 leading-tight">Venues · Quotes · Availability</span>
          </span>
          <Sparkles className="w-4 h-4 text-liberty-300 sm:hidden" />
        </button>
      </div>

      {/* Panel */}
      <div
        role="dialog"
        aria-label="AI event concierge chat"
        className={`fixed z-[61] inset-0 sm:inset-auto sm:bottom-5 sm:right-5 sm:w-[400px] sm:h-[min(660px,calc(100vh-40px))] bg-ivory sm:rounded-xl shadow-2xl ring-1 ring-charcoal/10 flex flex-col overflow-hidden origin-bottom-right transition-all duration-300 ${open ? 'opacity-100 scale-100' : 'opacity-0 scale-95 pointer-events-none'}`}
      >
        <header className="bg-gradient-to-br from-charcoal via-charcoal to-liberty-900 text-white px-4 py-3.5 flex items-center gap-3 shrink-0">
          <span className="relative shrink-0">
            <img src={CHAT_ASSISTANT.avatar} alt="Patti Golden" className="w-11 h-11 rounded-full object-cover ring-2 ring-liberty-400" />
            <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-400 ring-2 ring-charcoal" />
          </span>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <span className="font-serif text-lg leading-tight">{CHAT_ASSISTANT.name}</span>
              <span className="text-[9px] tracking-[0.2em] uppercase bg-liberty-500/30 text-liberty-100 px-1.5 py-0.5 rounded">AI</span>
            </div>
            <div className="text-[11px] text-white/60 truncate">{CHAT_ASSISTANT.title} · Ellis & Liberty Island Events</div>
          </div>
          <button onClick={restart} className="p-2 text-white/60 hover:text-white rounded hover:bg-white/10" title="Start a new conversation" aria-label="Restart chat">
            <RotateCcw className="w-4 h-4" />
          </button>
          <button onClick={() => setOpen(false)} className="p-2 text-white/60 hover:text-white rounded hover:bg-white/10" aria-label="Minimize chat">
            <ChevronDown className="w-5 h-5 hidden sm:block" />
            <X className="w-5 h-5 sm:hidden" />
          </button>
        </header>

        {(hasEventInfo || state.inquiryId) && (
          <div className={`px-4 py-2 text-xs flex flex-wrap items-center gap-x-3 gap-y-1 border-b shrink-0 ${state.inquiryId ? 'bg-emerald-50 border-emerald-100 text-emerald-800' : 'bg-white border-charcoal/5 text-charcoal/70'}`}>
            {state.inquiryId ? (
              <span className="inline-flex items-center gap-1.5 font-medium"><CheckCircle2 className="w-3.5 h-3.5" /> Details sent to Patti's team</span>
            ) : (
              <span className="font-medium text-charcoal/50 uppercase tracking-wider text-[10px]">Your event</span>
            )}
            {lead.event_type && <span className="inline-flex items-center gap-1"><PartyPopper className="w-3 h-3" />{lead.event_type}</span>}
            {lead.event_date && <span className="inline-flex items-center gap-1"><CalendarDays className="w-3 h-3" />{fmtDate(lead.event_date)}</span>}
            {lead.guest_count && <span className="inline-flex items-center gap-1"><Users className="w-3 h-3" />{lead.guest_count.toLocaleString()} guests</span>}
          </div>
        )}

        <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-5 space-y-4">
          {state.messages.map((m, i) =>
            m.role === 'assistant' ? (
              <div key={i} className="flex gap-2.5 items-end max-w-[92%]">
                <img src={CHAT_ASSISTANT.avatar} alt="" className="w-7 h-7 rounded-full object-cover shrink-0" />
                <div className="bg-white border border-charcoal/5 shadow-sm rounded-2xl rounded-bl-sm px-4 py-2.5 text-[14px] leading-relaxed text-charcoal/85">
                  <ChatMessageContent text={m.content} />
                </div>
              </div>
            ) : (
              <div key={i} className="flex justify-end">
                <div className="max-w-[85%] bg-liberty-700 text-white rounded-2xl rounded-br-sm px-4 py-2.5 text-[14px] leading-relaxed whitespace-pre-wrap break-words">
                  {m.content}
                </div>
              </div>
            )
          )}
          {loading && (
            <div className="flex gap-2.5 items-end">
              <img src={CHAT_ASSISTANT.avatar} alt="" className="w-7 h-7 rounded-full object-cover shrink-0" />
              <div className="bg-white border border-charcoal/5 rounded-2xl rounded-bl-sm px-4 py-3 flex gap-1">
                {[0, 150, 300].map((d) => (
                  <span key={d} className="w-2 h-2 rounded-full bg-liberty-500/70 animate-bounce" style={{ animationDelay: `${d}ms` }} />
                ))}
              </div>
            </div>
          )}
          {!loading && state.suggestions.length > 0 && (
            <div className="flex flex-wrap gap-2 pl-9">
              {state.suggestions.map((s) => (
                <button key={s} onClick={() => send(s)} className="text-xs px-3 py-1.5 rounded-full border border-liberty-600/40 text-liberty-800 bg-white hover:bg-liberty-600 hover:text-white transition">
                  {s}
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="shrink-0 border-t border-charcoal/10 bg-white">
          <div className="flex gap-2 px-3 pt-2.5">
            <Link to={RFQ_PATH} className="flex-1 inline-flex items-center justify-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider py-1.5 bg-liberty-700 text-white hover:bg-liberty-800 rounded">
              <FileText className="w-3.5 h-3.5" /> Request a Quote
            </Link>
            <a href={PATTI_PHONE.href} className="flex-1 inline-flex items-center justify-center gap-1.5 text-[11px] font-medium uppercase tracking-wider py-1.5 border border-charcoal/10 text-charcoal/70 hover:border-liberty-600 hover:text-liberty-700 rounded" title={PATTI_PHONE.isCell ? "Call Patti's mobile" : 'Call the events team'}>
              <Phone className="w-3.5 h-3.5" /> Call Patti
            </a>
            {CONTACT.whatsappUrl ? (
              <a href={CONTACT.whatsappUrl} target="_blank" rel="noopener noreferrer" className="flex-1 inline-flex items-center justify-center gap-1.5 text-[11px] font-medium uppercase tracking-wider py-1.5 border border-emerald-600/30 text-emerald-700 hover:bg-emerald-50 rounded">
                <MessageCircle className="w-3.5 h-3.5" /> WhatsApp
              </a>
            ) : (
              <a href={CONTACT.bookingUrl} target="_blank" rel="noopener noreferrer" className="flex-1 inline-flex items-center justify-center gap-1.5 text-[11px] font-medium uppercase tracking-wider py-1.5 border border-charcoal/10 text-charcoal/70 hover:border-liberty-600 hover:text-liberty-700 rounded">
                <CalendarCheck className="w-3.5 h-3.5" /> Book a call
              </a>
            )}
          </div>
          <form
            onSubmit={(e) => { e.preventDefault(); send(input); }}
            className="flex items-end gap-2 p-3"
          >
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value.slice(0, 1500))}
              onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(input); } }}
              rows={1}
              placeholder="Ask about venues, dates, quotes…"
              className="flex-1 resize-none max-h-28 rounded-lg border border-charcoal/15 bg-ivory px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-liberty-500/40 focus:border-liberty-500"
              aria-label="Message"
            />
            <button type="submit" disabled={!input.trim() || loading} className="h-10 w-10 shrink-0 rounded-lg bg-liberty-700 text-white flex items-center justify-center hover:bg-liberty-800 disabled:opacity-40" aria-label="Send message">
              <Send className="w-4 h-4" />
            </button>
          </form>
          <p className="px-4 pb-2.5 -mt-1 text-[10px] text-charcoal/40 leading-snug">
            AI assistant — details are confirmed by our events team. Chats are saved to help us follow up.
          </p>
        </div>
      </div>
    </>
  );
}
