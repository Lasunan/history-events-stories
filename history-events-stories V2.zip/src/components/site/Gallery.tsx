import { useCallback, useEffect, useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight, X, Expand } from 'lucide-react';
import { GALLERY, GALLERY_CATEGORIES } from '@/data/site';
import SectionHeading from './SectionHeading';
import { useReveal } from '@/hooks/useReveal';

export default function Gallery() {
  const [cat, setCat] = useState<(typeof GALLERY_CATEGORIES)[number]>('All');
  const [index, setIndex] = useState<number | null>(null);
  const items = useMemo(() => (cat === 'All' ? GALLERY : GALLERY.filter((g) => g.category === cat)), [cat]);
  useReveal([cat]);

  const close = useCallback(() => setIndex(null), []);
  const step = useCallback(
    (d: number) => setIndex((i) => (i === null ? i : (i + d + items.length) % items.length)),
    [items.length]
  );

  useEffect(() => {
    if (index === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
      if (e.key === 'ArrowRight') step(1);
      if (e.key === 'ArrowLeft') step(-1);
    };
    window.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [index, close, step]);

  const current = index !== null ? items[index] : null;

  return (
    <section id="gallery" className="py-24 lg:py-32 bg-ivory">
      <div className="max-w-7xl mx-auto px-5 lg:px-8">
        <SectionHeading
          eyebrow="Galleries"
          title="Moments from Past Events"
          subtitle="See how truly awe-inspiring our venues can be — and imagine your next event here."
        />

        <div className="flex flex-wrap justify-center gap-x-8 gap-y-3 mb-12 border-b border-charcoal/10">
          {GALLERY_CATEGORIES.map((c) => (
            <button
              key={c}
              onClick={() => setCat(c)}
              className={`pb-4 -mb-px font-serif text-xs tracking-[0.25em] uppercase border-b-2 transition ${
                cat === c ? 'border-liberty-600 text-liberty-700' : 'border-transparent text-charcoal/55 hover:text-charcoal'
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        <div className="columns-1 sm:columns-2 lg:columns-3 gap-5 [&>*]:mb-5">
          {items.map((g, i) => (
            <button
              key={g.src + cat}
              onClick={() => setIndex(i)}
              className="reveal group relative block w-full overflow-hidden break-inside-avoid"
              aria-label={`Open ${g.title}`}
            >
              <img
                src={g.src}
                alt={g.title}
                loading="lazy"
                className={`w-full object-cover transition-transform duration-[1200ms] group-hover:scale-105 ${g.tall ? 'aspect-[3/4]' : 'aspect-[4/3]'}`}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-liberty-950/85 via-liberty-950/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <div className="absolute inset-x-0 bottom-0 p-5 flex items-end justify-between text-left translate-y-3 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
                <div>
                  <div className="text-[10px] tracking-[0.25em] uppercase text-liberty-200">{g.category}</div>
                  <div className="font-serif text-white mt-1">{g.title}</div>
                </div>
                <Expand className="w-5 h-5 text-white" />
              </div>
            </button>
          ))}
        </div>
      </div>

      {current && (
        <div className="fixed inset-0 z-[70] bg-black/95 flex items-center justify-center animate-fade-in" onClick={close} role="dialog" aria-modal="true">
          <button onClick={close} className="absolute top-5 right-5 text-white/70 hover:text-white z-10" aria-label="Close">
            <X className="w-8 h-8" />
          </button>
          <button onClick={(e) => { e.stopPropagation(); step(-1); }} className="absolute left-3 sm:left-6 text-white/70 hover:text-white p-3 z-10" aria-label="Previous">
            <ChevronLeft className="w-9 h-9" />
          </button>
          <figure className="max-w-6xl w-full px-16" onClick={(e) => e.stopPropagation()}>
            <img src={current.src} alt={current.title} className="max-h-[80vh] w-auto mx-auto object-contain" />
            <figcaption className="mt-5 text-center">
              <div className="font-serif text-white text-lg">{current.title}</div>
              <div className="text-white/50 text-sm mt-1">{(index ?? 0) + 1} / {items.length} · {current.category}</div>
            </figcaption>
          </figure>
          <button onClick={(e) => { e.stopPropagation(); step(1); }} className="absolute right-3 sm:right-6 text-white/70 hover:text-white p-3 z-10" aria-label="Next">
            <ChevronRight className="w-9 h-9" />
          </button>
        </div>
      )}
    </section>
  );
}
