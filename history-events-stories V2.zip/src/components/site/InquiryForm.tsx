import { useEffect, useState } from 'react';
import { CheckCircle2, Loader2, Phone, Mail, MapPin, CalendarClock, AlertCircle, MessageCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { subscribeToCrm, isValidEmail } from '@/lib/crm';
import { CONTACT, IMG, INQUIRY_EVENT_TYPES, PATTI_PHONE, VENUES } from '@/data/site';

export interface InquiryPreset {
  venue?: string;
  eventType?: string;
  nonce: number;
}

const EMPTY = {
  firstName: '', lastName: '', email: '', phone: '', company: '',
  eventType: '', venue: '', eventDate: '', guests: '', message: '',
};
type Form = typeof EMPTY;

const today = new Date().toISOString().split('T')[0];

export default function InquiryForm({ preset }: { preset: InquiryPreset }) {
  const [form, setForm] = useState<Form>(EMPTY);
  const [smsOptIn, setSmsOptIn] = useState(true);
  const [errors, setErrors] = useState<Partial<Record<keyof Form, string>>>({});
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');

  useEffect(() => {
    if (!preset.nonce) return;
    setForm((f) => ({
      ...f,
      venue: preset.venue ?? f.venue,
      eventType: preset.eventType ?? f.eventType,
    }));
    setStatus('idle');
    const t = setTimeout(() => document.getElementById('inquire')?.scrollIntoView({ behavior: 'smooth' }), 150);
    return () => clearTimeout(t);
  }, [preset]);

  const set = (k: keyof Form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setForm((f) => ({ ...f, [k]: e.target.value }));
    if (errors[k]) setErrors((er) => ({ ...er, [k]: undefined }));
  };

  const validate = () => {
    const e: Partial<Record<keyof Form, string>> = {};
    if (!form.firstName.trim()) e.firstName = 'Required';
    if (!form.lastName.trim()) e.lastName = 'Required';
    if (!isValidEmail(form.email)) e.email = 'Please enter a valid email';
    if (form.phone.trim() && form.phone.replace(/\D/g, '').length < 7) e.phone = 'Please enter a valid phone number';
    if (!form.eventType) e.eventType = 'Please select an event type';
    if (form.eventDate && form.eventDate < today) e.eventDate = 'Please choose a future date';
    const g = Number(form.guests);
    if (form.guests && (!Number.isFinite(g) || g < 1 || g > 5000)) e.guests = 'Enter a guest count';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = async (ev: React.FormEvent) => {
    ev.preventDefault();
    if (!validate()) return;
    setStatus('loading');
    try {
      const name = `${form.firstName.trim()} ${form.lastName.trim()}`;
      const [dbRes] = await Promise.allSettled([
        supabase.from('event_inquiries').insert({
          first_name: form.firstName.trim(),
          last_name: form.lastName.trim(),
          email: form.email.trim(),
          phone: form.phone.trim() || null,
          company: form.company.trim() || null,
          event_type: form.eventType,
          venue: form.venue || null,
          event_date: form.eventDate || null,
          guest_count: form.guests ? Number(form.guests) : null,
          message: form.message.trim() || null,
          sms_opt_in: form.phone.trim() ? smsOptIn : false,
        }),
        subscribeToCrm({
          email: form.email.trim(),
          name,
          phone: form.phone,
          sms_opt_in: smsOptIn,
          source: 'contact-form',
          tags: ['event-inquiry', form.eventType.toLowerCase().replace(/[^a-z0-9]+/g, '-'), ...(form.venue ? ['venue-interest'] : [])],
        }),
      ]);
      if (dbRes.status === 'rejected' || (dbRes.status === 'fulfilled' && dbRes.value.error)) {
        throw new Error('save failed');
      }
      setStatus('success');
      setForm(EMPTY);
    } catch {
      setStatus('error');
    }
  };

  const Err = ({ k }: { k: keyof Form }) =>
    errors[k] ? <p className="mt-1.5 text-xs text-red-600">{errors[k]}</p> : null;

  return (
    <section id="inquire" className="relative bg-charcoal">
      <div className="grid lg:grid-cols-12">
        <div className="lg:col-span-5 relative min-h-[420px] lg:min-h-full">
          <img src={IMG.torchSunset} alt="Statue of Liberty torch at sunset" className="absolute inset-0 w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-b from-liberty-950/80 via-liberty-900/70 to-charcoal/95" />
          <div className="relative h-full flex flex-col justify-between p-8 sm:p-12 lg:p-14 text-white">
            <div>
              <div className="engraved-rule text-liberty-300 mb-5 max-w-xs">
                <span className="eyebrow text-liberty-200">Book Your Special Event</span>
              </div>
              <h2 className="font-serif text-3xl sm:text-4xl leading-tight">Reserve a Monumental Venue</h2>
              <p className="mt-5 font-display text-xl text-white/80 leading-relaxed">
                Inquire about available dates. Our team will get back to you within 24 hours with a customized quote
                that fits your needs and budget.
              </p>
            </div>
            <ul className="mt-12 space-y-5 text-white/85">
              <li>
                <a href={PATTI_PHONE.href} className="flex items-center gap-4 hover:text-white">
                  <Phone className="w-5 h-5 text-liberty-300" />
                  <span>{PATTI_PHONE.display}<span className="block text-xs text-white/50">{PATTI_PHONE.isCell ? "Patti's mobile" : 'Call Patti & the events team'}</span></span>
                </a>
              </li>
              {CONTACT.whatsappUrl && (
                <li>
                  <a href={CONTACT.whatsappUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 hover:text-white">
                    <MessageCircle className="w-5 h-5 text-emerald-300" />
                    <span>WhatsApp Patti<span className="block text-xs text-white/50">Message her directly on WhatsApp Business</span></span>
                  </a>
                </li>
              )}
              <li><a href={`mailto:${CONTACT.email}`} className="flex items-center gap-4 hover:text-white"><Mail className="w-5 h-5 text-liberty-300" />{CONTACT.email}</a></li>
              <li><a href={CONTACT.mapsUrl} target="_blank" rel="noopener noreferrer" className="flex items-start gap-4 hover:text-white"><MapPin className="w-5 h-5 text-liberty-300 mt-0.5 shrink-0" />{CONTACT.address}</a></li>
              <li><a href={CONTACT.bookingUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 hover:text-white"><CalendarClock className="w-5 h-5 text-liberty-300" />Schedule a planning call</a></li>
            </ul>

          </div>
        </div>

        <div className="lg:col-span-7 bg-ivory p-8 sm:p-12 lg:p-16">
          {status === 'success' ? (
            <div className="h-full flex flex-col items-center justify-center text-center py-16 animate-fade-in">
              <CheckCircle2 className="w-16 h-16 text-liberty-600" strokeWidth={1.3} />
              <h3 className="font-serif text-3xl mt-6">Thank You</h3>
              <p className="mt-4 text-charcoal/70 max-w-md leading-relaxed">
                Your inquiry has been received. A member of our events team will reach out within 24 hours to discuss
                availability and a customized quote.
              </p>
              <div className="mt-8 flex flex-col sm:flex-row gap-3">
                <a href={CONTACT.bookingUrl} target="_blank" rel="noopener noreferrer" className="btn-primary">Schedule a Call</a>
                <button onClick={() => setStatus('idle')} className="btn-outline">Send Another Inquiry</button>
              </div>
            </div>
          ) : (
            <form onSubmit={submit} noValidate className="grid sm:grid-cols-2 gap-x-5 gap-y-6">
              <div>
                <label className="field-label" htmlFor="firstName">First Name *</label>
                <input id="firstName" className="field" value={form.firstName} onChange={set('firstName')} autoComplete="given-name" />
                <Err k="firstName" />
              </div>
              <div>
                <label className="field-label" htmlFor="lastName">Last Name *</label>
                <input id="lastName" className="field" value={form.lastName} onChange={set('lastName')} autoComplete="family-name" />
                <Err k="lastName" />
              </div>
              <div>
                <label className="field-label" htmlFor="email">Email *</label>
                <input id="email" type="email" className="field" value={form.email} onChange={set('email')} autoComplete="email" />
                <Err k="email" />
              </div>
              <div>
                <label className="field-label" htmlFor="phone">Phone number (optional)</label>
                <input id="phone" type="tel" className="field" value={form.phone} onChange={set('phone')} autoComplete="tel" placeholder="(555) 555-5555" />
                <Err k="phone" />
              </div>
              <div className="sm:col-span-2 -mt-2">
                <label className="flex items-start gap-3 text-sm text-charcoal/70 cursor-pointer">
                  <input type="checkbox" checked={smsOptIn} onChange={(e) => setSmsOptIn(e.target.checked)} className="mt-1 w-4 h-4 accent-liberty-600" />
                  <span>Text me updates about my inquiry. Msg & data rates may apply. Reply STOP to unsubscribe.</span>
                </label>
              </div>
              <div className="sm:col-span-2">
                <label className="field-label" htmlFor="company">Company / Organization</label>
                <input id="company" className="field" value={form.company} onChange={set('company')} autoComplete="organization" />
              </div>
              <div>
                <label className="field-label" htmlFor="eventType">Event Type *</label>
                <select id="eventType" className="field" value={form.eventType} onChange={set('eventType')}>
                  <option value="">Select an event type</option>
                  {INQUIRY_EVENT_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                </select>
                <Err k="eventType" />
              </div>
              <div>
                <label className="field-label" htmlFor="venue">Preferred Venue</label>
                <select id="venue" className="field" value={form.venue} onChange={set('venue')}>
                  <option value="">Not sure yet</option>
                  <optgroup label="Ellis Island">
                    {VENUES.filter((v) => v.island === 'Ellis Island').map((v) => <option key={v.id} value={v.name}>{v.name}</option>)}
                  </optgroup>
                  <optgroup label="Liberty Island">
                    {VENUES.filter((v) => v.island === 'Liberty Island').map((v) => <option key={v.id} value={v.name}>{v.name}</option>)}
                  </optgroup>
                </select>
              </div>
              <div>
                <label className="field-label" htmlFor="eventDate">Preferred Event Date</label>
                <input id="eventDate" type="date" min={today} className="field" value={form.eventDate} onChange={set('eventDate')} />
                <Err k="eventDate" />
                <p className="mt-1.5 text-xs text-charcoal/50">NPS applications are submitted at least 6 weeks prior.</p>
              </div>
              <div>
                <label className="field-label" htmlFor="guests">Estimated Guest Count</label>
                <input id="guests" type="number" min={1} max={5000} className="field" value={form.guests} onChange={set('guests')} placeholder="e.g. 250" />
                <Err k="guests" />
              </div>
              <div className="sm:col-span-2">
                <label className="field-label" htmlFor="message">Tell Us About Your Event</label>
                <textarea id="message" rows={4} className="field resize-none" value={form.message} onChange={set('message')} placeholder="Timing, catering preferences, fireworks, ferry needs…" />
              </div>

              {status === 'error' && (
                <div className="sm:col-span-2 flex items-center gap-2 text-sm text-red-700 bg-red-50 border border-red-200 px-4 py-3">
                  <AlertCircle className="w-4 h-4" /> Something went wrong. Please try again or call {CONTACT.phoneDisplay}.
                </div>
              )}

              <div className="sm:col-span-2 flex flex-col sm:flex-row sm:items-center gap-4 justify-between">
                <p className="text-xs text-charcoal/50">* Required. All events are subject to National Park Service approval.</p>
                <button type="submit" disabled={status === 'loading'} className="btn-primary disabled:opacity-60">
                  {status === 'loading' ? <><Loader2 className="w-4 h-4 animate-spin" /> Sending</> : 'Request a Quote'}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}
