import { Fragment, type ReactNode } from 'react';
import { Link } from 'react-router-dom';

export function inline(text: string): ReactNode[] {
  const out: ReactNode[] = [];
  const re = /(\*\*([^*]+)\*\*)|(\[([^\]]+)\]\(([^)\s]+)\))/g;
  let last = 0;
  let m: RegExpExecArray | null;
  let i = 0;
  while ((m = re.exec(text))) {
    if (m.index > last) out.push(text.slice(last, m.index));
    if (m[2]) out.push(<strong key={i++} className="font-semibold text-charcoal">{m[2]}</strong>);
    else if (m[4] && m[5]) {
      const href = m[5];
      out.push(
        href.startsWith('/') ? (
          <Link key={i++} to={href} className="text-liberty-700 underline underline-offset-4 hover:text-liberty-900">{m[4]}</Link>
        ) : (
          <a key={i++} href={href} target="_blank" rel="noopener noreferrer" className="text-liberty-700 underline underline-offset-4 hover:text-liberty-900">{m[4]}</a>
        )
      );
    }
    last = m.index + m[0].length;
  }
  if (last < text.length) out.push(text.slice(last));
  return out;
}

export default function RichText({ text, className = '' }: { text: string; className?: string }) {
  const blocks = text.replace(/\r\n/g, '\n').split(/\n{2,}/).map((b) => b.trim()).filter(Boolean);
  return (
    <div className={`space-y-5 text-lg leading-relaxed text-charcoal/75 ${className}`}>
      {blocks.map((b, idx) => {
        if (b.startsWith('## ')) return <h3 key={idx} className="font-serif text-2xl sm:text-3xl text-charcoal pt-2">{inline(b.slice(3))}</h3>;
        const lines = b.split('\n');
        if (lines.every((l) => /^[-*] /.test(l))) {
          return (
            <ul key={idx} className="space-y-2 pl-1">
              {lines.map((l, j) => (
                <li key={j} className="flex gap-3"><span className="mt-2.5 w-1.5 h-1.5 rounded-full bg-liberty-500 shrink-0" />{inline(l.slice(2))}</li>
              ))}
            </ul>
          );
        }
        return (
          <p key={idx}>
            {lines.map((l, j) => <Fragment key={j}>{j > 0 && <br />}{inline(l)}</Fragment>)}
          </p>
        );
      })}
    </div>
  );
}
