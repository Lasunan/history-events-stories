import { Link } from 'react-router-dom';
import { ExternalLink, CalendarClock, Compass } from 'lucide-react';
import { CONTACT, IMG, VIRTUAL_TOURS } from '@/data/site';
import SectionHeading from './SectionHeading';

export default function Tours() {
  return (
    <section id="tours" className="relative py-24 lg:py-32 bg-charcoal overflow-hidden">
      <img src={IMG.fireworksReal} alt="" aria-hidden className="absolute inset-0 w-full h-full object-cover opacity-25" />
      <div className="absolute inset-0 bg-gradient-to-r from-charcoal via-charcoal/85 to-liberty-950/80" />
      <div className="relative max-w-7xl mx-auto px-5 lg:px-8">
        <SectionHeading
          light
          eyebrow="Virtual Tours"
          title="Come for a Monumental Tour"
          subtitle="Experience our venue spaces online — or schedule a call with our events team to plan an on-site visit."
        />

        <div className="grid md:grid-cols-3 gap-6">
          {VIRTUAL_TOURS.map((t) => (
            <a
              key={t.title}
              href={t.href}
              target="_blank"
              rel="noopener noreferrer"
              className="reveal group relative aspect-[4/3] overflow-hidden block"
            >
              <img src={t.image} alt={t.title} loading="lazy" className="absolute inset-0 w-full h-full object-cover transition-transform duration-[1200ms] group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal/90 via-charcoal/30 to-transparent" />
              <div className="absolute inset-0 flex flex-col justify-end p-6">
                <Compass className="w-7 h-7 text-liberty-300 mb-3" strokeWidth={1.4} />
                <div className="font-serif text-white text-xl">{t.title}</div>
                <div className="mt-2 inline-flex items-center gap-2 text-liberty-200 text-[11px] tracking-[0.22em] uppercase">
                  Start 360° Tour <ExternalLink className="w-3.5 h-3.5" />
                </div>
              </div>
            </a>
          ))}
        </div>

        <div className="reveal mt-14 flex flex-col sm:flex-row items-center justify-center gap-4">
          <a href={CONTACT.bookingUrl} target="_blank" rel="noopener noreferrer" className="btn-primary">
            <CalendarClock className="w-4 h-4" /> Schedule a Planning Call
          </a>
          <Link to="/inquire" className="btn-outline-light">Request a Quote</Link>
        </div>
      </div>
    </section>
  );
}
