import {
  Crown, HeartHandshake, Presentation, Rocket, Sparkles, Users, Clapperboard, Award,
  Flame, Ship, UtensilsCrossed, BookOpen, Landmark, type LucideProps,
} from 'lucide-react';

const MAP = { Crown, HeartHandshake, Presentation, Rocket, Sparkles, Users, Clapperboard, Award, Flame, Ship, UtensilsCrossed, BookOpen, Landmark };

export default function Icon({ name, ...props }: { name: string } & LucideProps) {
  const C = MAP[name as keyof typeof MAP] ?? Landmark;
  return <C {...props} />;
}
