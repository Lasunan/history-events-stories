import { Quote } from 'lucide-react';
import { CONTACT, IMG } from '@/data/site';

export default function Intro() {
  return (
    <section id="intro" className="py-24 lg:py-32 bg-ivory relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-5 lg:px-8 grid lg:grid-cols-12 gap-14 items-center">
        <div className="lg:col-span-5 reveal">
          <div className="relative max-w-md mx-auto">
            <div className="absolute -inset-4 border border-liberty-600/30" />
            <img src={IMG.medallion95} alt="Evelyn Hill Inc. 95 years medallion, 1931–2026" className="relative w-full bg-white" />
          </div>
        </div>
        <div className="lg:col-span-7 reveal">
          <div className="engraved-rule mb-5 max-w-xs">
            <span className="eyebrow">Evelyn Hill Inc.</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl leading-tight">
            Where Elegance Meets History
          </h2>
          <p className="mt-6 text-lg text-charcoal/75 leading-relaxed">
            Discover the enchanting Ellis Island Events of Evelyn Hill Inc. Nestled on iconic Ellis Island, we provide a
            unique venue for all your events, backed by 95 years of exceptional hospitality. With awe-inspiring views of
            the Statue of Liberty and the Manhattan skyline, our islands offer unforgettable settings for corporate events,
            stockholder receptions, fundraisers and special family celebrations.
          </p>
          <p className="mt-4 text-lg text-charcoal/75 leading-relaxed">
            Since 1990, Ellis Island and Liberty Island have welcomed corporate event planning groups, celebrities,
            political leaders, dignitaries and movie productions — and our award-winning sustainability practices make us
            a corporate event standout.
          </p>

          <figure className="mt-10 bg-white border-l-4 border-liberty-600 p-7 shadow-sm">
            <Quote className="w-8 h-8 text-liberty-400 mb-3" />
            <blockquote className="font-display italic text-xl sm:text-2xl text-charcoal/85 leading-relaxed">
              When you book your event, you will have exclusive use of a National Monument. Whether it be a dinner gala
              or an intimate private gathering, the possibilities are endless. I invite you to connect with me and give
              your next event the monumental evening it deserves.
            </blockquote>
            <figcaption className="mt-5 flex items-center gap-4">
              <img src={IMG.patti} alt="Patti Golden" className="w-12 h-12 rounded-full object-cover" />
              <div>
                <div className="font-serif text-sm tracking-[0.15em] uppercase">Patti Golden</div>
                <a href={`mailto:${CONTACT.email}`} className="text-sm text-liberty-600 hover:underline">
                  VP of Events · {CONTACT.email}
                </a>
              </div>
            </figcaption>
          </figure>
        </div>
      </div>
    </section>
  );
}
