import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';
import type { SitePage } from '@/data/pages';
import RichText from './RichText';

export default function PageHero({ page }: { page: SitePage }) {
  return (
    <>
      <section className="relative min-h-[62vh] flex items-end overflow-hidden bg-charcoal">
        <img src={page.hero_image} alt={page.hero_title} className="absolute inset-0 w-full h-full object-cover animate-slow-zoom" />
        <div className="absolute inset-0 bg-gradient-to-br from-liberty-900/85 via-charcoal/55 to-charcoal/90" />
        <div className="absolute inset-0 bg-gradient-to-t from-charcoal via-transparent to-charcoal/50" />
        <div className="relative max-w-7xl mx-auto px-5 lg:px-8 pt-40 pb-16 w-full">
          <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-xs tracking-[0.2em] uppercase text-white/60 mb-6">
            <Link to="/" className="hover:text-white">Home</Link>
            <ChevronRight className="w-3.5 h-3.5" />
            <span className="text-liberty-200">{page.nav_label}</span>
          </nav>
          <div className="flex items-center gap-4 mb-5 animate-fade-in">
            <span className="h-px w-12 bg-liberty-300" />
            <span className="font-serif text-liberty-200 text-xs sm:text-sm tracking-[0.35em] uppercase">{page.hero_eyebrow}</span>
          </div>
          <h1 className="font-serif text-white text-4xl sm:text-5xl lg:text-6xl leading-[1.08] max-w-4xl animate-slide-in">{page.hero_title}</h1>
          {page.hero_subtitle && (
            <p className="mt-6 font-display text-white/80 text-xl sm:text-2xl leading-relaxed max-w-3xl">{page.hero_subtitle}</p>
          )}
        </div>
      </section>
      {page.body.trim() && (
        <section className="bg-white py-16 lg:py-20 border-b border-charcoal/5">
          <div className="max-w-3xl mx-auto px-5 lg:px-8">
            <RichText text={page.body} />
          </div>
        </section>
      )}
    </>
  );
}
