import { ArrowRight, Info } from 'lucide-react';
import { ENHANCEMENTS, EVENT_TYPES, IMG } from '@/data/site';
import SectionHeading from './SectionHeading';
import Icon from './Icon';

const toInquiryType = (title: string) => EVENT_TYPES.find((e) => e.title === title)?.inquiry ?? 'Other';
export default function EventTypes({ onSelect }: { onSelect: (eventType: string) => void }) {
  return (
    <section id="events" className="relative py-24 lg:py-32 bg-liberty-900 overflow-hidden">
      <img src={IMG.greatHallGala} alt="" aria-hidden className="absolute inset-0 w-full h-full object-cover opacity-[0.12]" />
      <div className="absolute inset-0 bg-gradient-to-b from-liberty-950/60 via-liberty-900/80 to-liberty-950" />
      <div className="relative max-w-7xl mx-auto px-5 lg:px-8">
        <SectionHeading
          light
          eyebrow="Event Types"
          title="Events of Emotion, Excitement & Pride"
          subtitle="From black-tie galas to milestone family gatherings, our landmark keeps your guests talking for years to come."
        />

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-px bg-white/10 border border-white/10">
          {EVENT_TYPES.map((e, i) => (
            <button
              key={e.title}
              onClick={() => onSelect(toInquiryType(e.title))}
              className="reveal group text-left bg-liberty-950/70 hover:bg-liberty-800/80 p-8 transition-colors duration-500"
              style={{ transitionDelay: `${(i % 4) * 70}ms` }}
            >
              <div className="w-14 h-14 border border-liberty-300/50 flex items-center justify-center text-liberty-200 group-hover:bg-liberty-300 group-hover:text-liberty-950 transition-colors duration-500">
                <Icon name={e.icon} className="w-6 h-6" strokeWidth={1.4} />
              </div>
              <h3 className="mt-6 font-serif text-lg text-white tracking-wide">{e.title}</h3>
              <p className="mt-3 text-white/65 leading-relaxed text-[15px]">{e.text}</p>
              <span className="mt-6 inline-flex items-center gap-2 text-liberty-200 font-serif text-[11px] tracking-[0.22em] uppercase opacity-70 group-hover:opacity-100">
                Inquire <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </span>
            </button>
          ))}
        </div>

        <div className="mt-8 flex items-start gap-3 text-white/60 text-sm max-w-3xl mx-auto justify-center text-center reveal">
          <Info className="w-4 h-4 mt-0.5 shrink-0 text-liberty-300" />
          <span>All events must be approved by the National Park Service and show a meaningful association to the Monument. As of 2024, wedding events are no longer permitted.</span>
        </div>

        <div className="mt-24">
          <div className="engraved-rule text-liberty-300 justify-center mb-10 reveal">
            <span className="eyebrow text-liberty-200">Enhance Your Experience</span>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {ENHANCEMENTS.map((e) => (
              <div key={e.title} className="reveal flex gap-4 items-start">
                <Icon name={e.icon} className="w-7 h-7 text-liberty-300 shrink-0" strokeWidth={1.3} />
                <div>
                  <h4 className="font-serif text-white tracking-wide">{e.title}</h4>
                  <p className="mt-1.5 text-white/60 text-sm leading-relaxed">{e.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
