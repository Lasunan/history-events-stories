import { useState } from 'react';
import { Plus, Mail } from 'lucide-react';
import { CONTACT, FAQS } from '@/data/site';
import SectionHeading from './SectionHeading';

export default function Faq() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="py-24 lg:py-32 bg-ivory">
      <div className="max-w-7xl mx-auto px-5 lg:px-8 grid lg:grid-cols-12 gap-12">
        <div className="lg:col-span-4">
          <SectionHeading align="left" eyebrow="FAQ" title="The Key to Wisdom Is Knowing the Right Questions" />
          <div className="reveal -mt-6 bg-white p-7 border-t-4 border-liberty-600">
            <p className="text-charcoal/70 leading-relaxed">
              Can’t find an answer? Our VP of Events, <strong>Patti Golden</strong>, will gladly assist you.
            </p>
            <a href={`mailto:${CONTACT.email}`} className="mt-5 btn-outline !text-[11px]">
              <Mail className="w-4 h-4" /> {CONTACT.email}
            </a>
          </div>
        </div>
        <div className="lg:col-span-8 divide-y divide-charcoal/10 border-y border-charcoal/10">
          {FAQS.map((f, i) => {
            const isOpen = open === i;
            return (
              <div key={f.q} className="reveal">
                <button
                  onClick={() => setOpen(isOpen ? null : i)}
                  aria-expanded={isOpen}
                  className="w-full flex items-center justify-between gap-6 py-6 text-left group"
                >
                  <span className={`font-serif text-lg transition-colors ${isOpen ? 'text-liberty-700' : 'group-hover:text-liberty-700'}`}>{f.q}</span>
                  <span className={`w-9 h-9 shrink-0 border flex items-center justify-center transition-all duration-300 ${isOpen ? 'bg-liberty-600 border-liberty-600 text-white rotate-45' : 'border-charcoal/20 text-charcoal/60'}`}>
                    <Plus className="w-4 h-4" />
                  </span>
                </button>
                <div className={`grid transition-all duration-500 ${isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}>
                  <div className="overflow-hidden">
                    <p className="pb-6 pr-12 text-charcoal/70 leading-relaxed">{f.a}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
