import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Play, X, ChevronDown, Phone } from 'lucide-react';
import { CONTACT, STATS } from '@/data/site';
import type { SitePage } from '@/data/pages';

export default function Hero({ page }: { page: SitePage }) {
  const [video, setVideo] = useState(false);

  return (
    <section id="top" className="relative min-h-[100svh] flex flex-col overflow-hidden bg-charcoal">
      <img src={page.hero_image} alt={page.hero_title} className="absolute inset-0 w-full h-full object-cover animate-slow-zoom" />
      <div className="absolute inset-0 bg-gradient-to-br from-liberty-900/85 via-charcoal/55 to-charcoal/90" />
      <div className="absolute inset-0 bg-gradient-to-t from-charcoal via-transparent to-charcoal/40" />

      <div className="relative flex-1 flex items-center">
        <div className="max-w-7xl mx-auto px-5 lg:px-8 pt-32 pb-16 w-full">
          <div className="max-w-3xl">
            <div className="flex items-center gap-4 mb-7 animate-fade-in">
              <span className="h-px w-12 bg-liberty-300" />
              <span className="font-serif text-liberty-200 text-xs sm:text-sm tracking-[0.35em] uppercase">{page.hero_eyebrow}</span>
            </div>
            <h1 className="font-serif text-white text-4xl sm:text-6xl lg:text-7xl leading-[1.05] animate-slide-in">{page.hero_title}</h1>
            <p className="mt-7 font-display text-white/80 text-xl sm:text-2xl leading-relaxed max-w-2xl">{page.hero_subtitle}</p>
            <div className="mt-10 flex flex-col sm:flex-row gap-4">
              <Link to="/inquire" className="btn-primary">Plan Your Event</Link>
              <Link to="/venues" className="btn-outline-light">Explore Venues</Link>
              <button
                onClick={() => setVideo(true)}
                className="group inline-flex items-center gap-3 text-white font-serif text-sm tracking-[0.2em] uppercase px-2 py-3"
              >
                <span className="w-11 h-11 rounded-full border border-white/60 flex items-center justify-center group-hover:bg-white group-hover:text-charcoal transition">
                  <Play className="w-4 h-4 ml-0.5" />
                </span>
                Watch Film
              </button>
            </div>
            <a href={CONTACT.phoneHref} className="mt-8 inline-flex items-center gap-2 text-white/70 hover:text-white text-sm">
              <Phone className="w-4 h-4 text-liberty-300" /> Speak with our events team: {CONTACT.phoneDisplay}
            </a>
          </div>
        </div>
      </div>

      <div className="relative border-t border-white/10 bg-charcoal/60 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-5 lg:px-8 grid grid-cols-2 md:grid-cols-4">
          {STATS.map((s, i) => (
            <div key={s.label} className={`py-6 text-center ${i > 0 ? 'md:border-l border-white/10' : ''}`}>
              <div className="font-serif text-2xl sm:text-3xl text-white">{s.value}</div>
              <div className="mt-1 text-[11px] tracking-[0.25em] uppercase text-liberty-200/80">{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      <button
        onClick={() => document.getElementById('intro')?.scrollIntoView({ behavior: 'smooth' })}
        aria-label="Scroll down"
        className="absolute bottom-28 left-1/2 -translate-x-1/2 text-white/60 hover:text-white hidden md:block animate-bounce"
      >
        <ChevronDown className="w-6 h-6" />
      </button>

      {video && (
        <div className="fixed inset-0 z-[70] bg-black/90 flex items-center justify-center p-4" onClick={() => setVideo(false)}>
          <button className="absolute top-5 right-5 text-white/80 hover:text-white" aria-label="Close video" onClick={() => setVideo(false)}>
            <X className="w-8 h-8" />
          </button>
          <div className="w-full max-w-5xl aspect-video" onClick={(e) => e.stopPropagation()}>
            <iframe
              src="https://player.vimeo.com/video/1006193748?autoplay=1&title=0&byline=0&portrait=0"
              className="w-full h-full"
              allow="autoplay; fullscreen; picture-in-picture"
              allowFullScreen
              title="Ellis Island Events promo film"
            />
          </div>
        </div>
      )}
    </section>
  );
}
