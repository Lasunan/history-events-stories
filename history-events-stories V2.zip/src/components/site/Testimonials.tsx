import { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, Quote, Star } from 'lucide-react';
import { TESTIMONIALS } from '@/data/site';

export default function Testimonials() {
  const [i, setI] = useState(0);
  const [paused, setPaused] = useState(false);
  const n = TESTIMONIALS.length;
  const go = (d: number) => setI((p) => (p + d + n) % n);

  useEffect(() => {
    if (paused) return;
    const t = setTimeout(() => go(1), 7000);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [i, paused]);

  return (
    <section className="py-24 lg:py-32 bg-liberty-50" onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)}>
      <div className="max-w-4xl mx-auto px-5 lg:px-8 text-center">
        <div className="engraved-rule justify-center mb-8 reveal">
          <span className="eyebrow">Kind Words</span>
        </div>
        <Quote className="w-12 h-12 text-liberty-400 mx-auto" strokeWidth={1.2} />
        <div className="relative mt-6 min-h-[260px] sm:min-h-[220px]">
          {TESTIMONIALS.map((t, idx) => (
            <figure
              key={idx}
              aria-hidden={idx !== i}
              className={`absolute inset-0 transition-all duration-700 ${idx === i ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'}`}
            >
              <div className="flex justify-center gap-1 mb-5 text-liberty-600">
                {Array.from({ length: 5 }).map((_, s) => <Star key={s} className="w-4 h-4 fill-current" />)}
              </div>
              <blockquote className="font-display italic text-2xl sm:text-3xl leading-relaxed text-charcoal/85">
                “{t.quote}”
              </blockquote>
              <figcaption className="mt-7">
                <div className="font-serif tracking-[0.18em] uppercase text-sm">{t.name}</div>
                <div className="text-charcoal/55 text-sm mt-1">{t.org}</div>
              </figcaption>
            </figure>
          ))}
        </div>

        <div className="mt-10 flex items-center justify-center gap-6">
          <button onClick={() => go(-1)} aria-label="Previous testimonial" className="w-11 h-11 border border-liberty-600/40 text-liberty-700 hover:bg-liberty-600 hover:text-white transition flex items-center justify-center">
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div className="flex gap-2">
            {TESTIMONIALS.map((_, idx) => (
              <button key={idx} onClick={() => setI(idx)} aria-label={`Go to testimonial ${idx + 1}`} className={`h-1.5 transition-all duration-500 ${idx === i ? 'w-10 bg-liberty-600' : 'w-4 bg-liberty-600/25 hover:bg-liberty-600/50'}`} />
            ))}
          </div>
          <button onClick={() => go(1)} aria-label="Next testimonial" className="w-11 h-11 border border-liberty-600/40 text-liberty-700 hover:bg-liberty-600 hover:text-white transition flex items-center justify-center">
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </section>
  );
}
