import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Instagram, Linkedin, Youtube, Phone, Mail, MapPin, Loader2, Check, ArrowUp } from 'lucide-react';
import { CONTACT, IMG, SOCIALS, VENUES } from '@/data/site';
import { subscribeToCrm, isValidEmail } from '@/lib/crm';

const SOCIAL_ICONS = { Facebook, Instagram, LinkedIn: Linkedin, YouTube: Youtube } as const;

const RESOURCES: { label: string; href: string; external?: boolean }[] = [
  { label: 'Book an Event', href: '/inquire' },
  { label: 'Venues', href: '/venues' },
  { label: 'Event Types', href: '/events' },
  { label: 'Galleries', href: '/gallery' },
  { label: 'About Us', href: '/about' },
  { label: 'Virtual Tours', href: '/tours' },
  { label: 'FAQ', href: '/faq' },
  { label: 'Vendor Guidelines', href: 'https://ellisisland-events.com/vendor-guidelines', external: true },
  { label: 'PDF Downloads', href: 'https://ellisisland-events.com/pdf-downloads', external: true },
  { label: 'Privacy Policy', href: 'https://ellisisland-events.com/privacy-policy', external: true },
];

export default function Footer({ onVenue }: { onVenue: (name: string) => void }) {
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [sms, setSms] = useState(true);
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [err, setErr] = useState('');

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isValidEmail(email)) { setErr('Please enter a valid email address.'); return; }
    setErr('');
    setStatus('loading');
    try {
      await subscribeToCrm({ email: email.trim(), phone, sms_opt_in: sms, source: 'footer-signup', tags: ['newsletter', 'footer-signup'] });
      setStatus('success');
      setEmail(''); setPhone('');
    } catch {
      setStatus('error');
      setErr('Could not subscribe right now. Please try again.');
    }
  };

  return (
    <footer className="bg-charcoal text-white/70">
      <div className="border-b border-white/10">
        <div className="max-w-7xl mx-auto px-5 lg:px-8 py-14 grid lg:grid-cols-2 gap-10 items-center">
          <div>
            <div className="eyebrow text-liberty-300">The Monumental Letter</div>
            <h3 className="font-serif text-white text-2xl sm:text-3xl mt-3">Seasonal dates, new experiences & event inspiration</h3>
          </div>
          {status === 'success' ? (
            <div className="flex items-center gap-3 text-liberty-200">
              <Check className="w-6 h-6" /> Thank you — you are on the list.
            </div>
          ) : (
            <form onSubmit={submit} noValidate className="space-y-3">
              <div className="flex flex-col sm:flex-row gap-3">
                <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email address" aria-label="Email address" className="flex-1 bg-white/5 border border-white/15 px-4 py-3 text-white placeholder:text-white/40 focus:outline-none focus:border-liberty-400" />
                <input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Phone number (optional)" aria-label="Phone number (optional)" className="sm:w-52 bg-white/5 border border-white/15 px-4 py-3 text-white placeholder:text-white/40 focus:outline-none focus:border-liberty-400" />
                <button type="submit" disabled={status === 'loading'} className="btn-primary !py-3 disabled:opacity-60">
                  {status === 'loading' ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Subscribe'}
                </button>
              </div>
              <label className="flex items-start gap-2.5 text-xs text-white/55 cursor-pointer">
                <input type="checkbox" checked={sms} onChange={(e) => setSms(e.target.checked)} className="mt-0.5 accent-liberty-500" />
                Text me updates. Msg & data rates may apply. Reply STOP to unsubscribe.
              </label>
              {err && <p className="text-xs text-red-400">{err}</p>}
            </form>
          )}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-5 lg:px-8 py-16 grid sm:grid-cols-2 lg:grid-cols-12 gap-12">
        <div className="lg:col-span-4">
          <div className="flex items-center gap-4">
            <img src={IMG.logo} alt="Evelyn Hill Inc. logo" className="h-24 w-auto bg-white p-0.5" />
            <div>
              <div className="font-serif text-white text-xl tracking-[0.1em]">Ellis Island Events</div>
              <div className="font-serif text-liberty-300 text-[11px] tracking-[0.3em] uppercase mt-1">Evelyn Hill Inc.</div>
            </div>
          </div>
          <p className="mt-6 leading-relaxed text-sm">
            Unique event venues on Ellis Island & Liberty Island, New York. Hospitality partner at the Statue of Liberty since 1931.
          </p>
          <div className="mt-6 flex gap-3">
            {SOCIALS.map((s) => {
              const I = SOCIAL_ICONS[s.name];
              return (
                <a key={s.name} href={s.href} target="_blank" rel="noopener noreferrer" aria-label={s.name} className="w-10 h-10 border border-white/15 flex items-center justify-center hover:bg-liberty-600 hover:border-liberty-600 hover:text-white transition">
                  <I className="w-4 h-4" />
                </a>
              );
            })}
          </div>
        </div>

        <div className="lg:col-span-3">
          <h4 className="font-serif text-white text-sm tracking-[0.2em] uppercase mb-5">Event Spaces</h4>
          <ul className="space-y-2.5 text-sm">
            {VENUES.slice(0, 7).map((v) => (
              <li key={v.id}>
                <button onClick={() => onVenue(v.name)} className="hover:text-liberty-300 transition text-left">{v.name}</button>
              </li>
            ))}
          </ul>
        </div>

        <div className="lg:col-span-2">
          <h4 className="font-serif text-white text-sm tracking-[0.2em] uppercase mb-5">Explore</h4>
          <ul className="space-y-2.5 text-sm">
            {RESOURCES.map((r) => (
              <li key={r.label}>
                {r.external ? (
                  <a href={r.href} target="_blank" rel="noopener noreferrer" className="hover:text-liberty-300 transition">{r.label}</a>
                ) : (
                  <Link to={r.href} className="hover:text-liberty-300 transition">{r.label}</Link>
                )}
              </li>
            ))}
          </ul>
        </div>

        <div className="lg:col-span-3">
          <h4 className="font-serif text-white text-sm tracking-[0.2em] uppercase mb-5">Contact</h4>
          <ul className="space-y-4 text-sm">
            <li><a href={CONTACT.phoneHref} className="flex gap-3 hover:text-white"><Phone className="w-4 h-4 text-liberty-400 mt-0.5" />{CONTACT.phoneDisplay}</a></li>
            <li><a href={`mailto:${CONTACT.email}`} className="flex gap-3 hover:text-white"><Mail className="w-4 h-4 text-liberty-400 mt-0.5" />{CONTACT.email}</a></li>
            <li><a href={`mailto:${CONTACT.corporateEmail}?subject=Corporate%20RFQ`} className="flex gap-3 hover:text-white"><Mail className="w-4 h-4 text-liberty-400 mt-0.5" />{CONTACT.corporateEmail}</a></li>
            <li><a href={CONTACT.mapsUrl} target="_blank" rel="noopener noreferrer" className="flex gap-3 hover:text-white"><MapPin className="w-4 h-4 text-liberty-400 mt-0.5 shrink-0" />{CONTACT.address}</a></li>
          </ul>
          <a href={CONTACT.bookingUrl} target="_blank" rel="noopener noreferrer" className="btn-outline !border-liberty-400 !text-liberty-200 hover:!text-white mt-6 !text-[11px]">Schedule a Call</a>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-5 lg:px-8 py-6 flex flex-col md:flex-row gap-4 items-center justify-between text-xs text-white/50">
          <p>
            <a href={CONTACT.parentSite} target="_blank" rel="noopener noreferrer" className="hover:text-white">Evelyn Hill Inc.</a>, is an authorized concessioner to the National Park Service. © {new Date().getFullYear()} Ellis Island Events | All Rights Reserved.
          </p>
          <div className="flex items-center gap-6">
            <Link to="/admin" className="hover:text-white">Team Login</Link>
            <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="flex items-center gap-2 hover:text-white">Back to top <ArrowUp className="w-3.5 h-3.5" /></button>
          </div>
        </div>
      </div>
    </footer>
  );
}
