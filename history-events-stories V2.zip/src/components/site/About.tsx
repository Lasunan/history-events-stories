import { Mail, Linkedin } from 'lucide-react';
import { IMG, TEAM, TIMELINE, CONTACT } from '@/data/site';
import SectionHeading from './SectionHeading';

export default function About() {
  return (
    <section id="about" className="py-24 lg:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-5 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="reveal relative">
            <img src={IMG.celebratoryHall} alt="Celebratory Hall on Ellis Island" className="w-full aspect-[4/5] object-cover" />
            <div className="absolute -bottom-8 -right-4 sm:-right-8 bg-liberty-600 text-white p-7 max-w-[260px] shadow-xl">
              <div className="font-serif text-5xl">1931</div>
              <div className="mt-2 text-sm text-white/85 leading-relaxed">
                The oldest family-owned concessioner for the National Park Service.
              </div>
            </div>
          </div>

          <div>
            <SectionHeading
              align="left"
              eyebrow="About Evelyn Hill Inc."
              title="Celebrating Ninety-Five Years at Lady Liberty"
            />
            <div className="reveal -mt-6 space-y-4 text-lg text-charcoal/75 leading-relaxed">
              <p>
                Since 1931, Evelyn Hill Inc. has been providing hospitality services at the Statue of Liberty and Ellis
                Island in New York City. Ellis Island Events is our Special Events division — a third-generation,
                family-owned company and your liaison to the National Park Service.
              </p>
              <p>
                We manage the Crown Café, Ellis Island Café, both retail shops and the Special Events on each Island. A
                Monumental Event deserves a venue of once-in-your-life proportions — and a team that knows every step.
              </p>
            </div>

            <ol className="reveal mt-10 relative border-l border-liberty-600/30 ml-2 space-y-7">
              {TIMELINE.map((t) => (
                <li key={t.year} className="pl-8 relative">
                  <span className="absolute -left-[7px] top-1.5 w-3.5 h-3.5 rounded-full bg-liberty-600 ring-4 ring-liberty-100" />
                  <div className="font-serif text-liberty-700 text-lg">{t.year}</div>
                  <p className="text-charcoal/70 mt-1">{t.text}</p>
                </li>
              ))}
            </ol>
          </div>
        </div>

        <div className="mt-32">
          <SectionHeading eyebrow="Our Team" title="The Liberty Ladies" subtitle="Your dedicated partners from first inquiry to the final firework." />
          <div className="grid sm:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {TEAM.map((m) => (
              <article key={m.name} className="reveal group bg-ivory flex flex-col sm:flex-row overflow-hidden shadow-sm hover:shadow-xl transition-shadow duration-500">
                <div className="sm:w-44 aspect-square sm:aspect-auto overflow-hidden shrink-0">
                  <img src={m.image} alt={m.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
                </div>
                <div className="p-7 flex flex-col justify-center">
                  <div className="eyebrow text-[10px]">Statue of Liberty & Ellis Island Events</div>
                  <h3 className="font-serif text-2xl mt-2">{m.name}</h3>
                  <div className="text-charcoal/60 mt-1">{m.role}</div>
                  <div className="mt-5 flex items-center gap-3">
                    <a href={`mailto:${m.email}?subject=Event%20Planning`} className="btn-outline !px-3 !py-2 !text-[10px]">
                      <Mail className="w-3.5 h-3.5" /> Email
                    </a>
                    {m.linkedin && (
                      <a href={m.linkedin} target="_blank" rel="noopener noreferrer" aria-label={`${m.name} on LinkedIn`} className="w-9 h-9 border border-liberty-600 text-liberty-700 flex items-center justify-center hover:bg-liberty-600 hover:text-white transition">
                        <Linkedin className="w-4 h-4" />
                      </a>
                    )}
                  </div>
                </div>
              </article>
            ))}
          </div>
          <p className="reveal text-center mt-10 text-charcoal/60">
            Call Patti Golden today at{' '}
            <a href={CONTACT.phoneHref} className="text-liberty-700 font-semibold hover:underline">{CONTACT.phoneDisplay}</a>
          </p>
        </div>
      </div>
    </section>
  );
}
