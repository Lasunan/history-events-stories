import { useEffect } from 'react';
import { X, Users, MapPin, Sun, Check } from 'lucide-react';
import type { Venue } from '@/data/site';

interface Props {
  venue: Venue | null;
  onClose: () => void;
  onRequest: (v: Venue) => void;
}

export default function VenueModal({ venue, onClose, onRequest }: Props) {
  useEffect(() => {
    if (!venue) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [venue, onClose]);

  if (!venue) return null;

  return (
    <div className="fixed inset-0 z-[60] bg-charcoal/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in" onClick={onClose} role="dialog" aria-modal="true" aria-label={venue.name}>
      <div className="bg-ivory max-w-4xl w-full max-h-[90vh] overflow-y-auto grid md:grid-cols-2 shadow-2xl animate-slide-in" onClick={(e) => e.stopPropagation()}>
        <div className="relative h-64 md:h-auto">
          <img src={venue.image} alt={venue.name} className="absolute inset-0 w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-charcoal/60 to-transparent" />
          <span className="absolute bottom-4 left-4 bg-liberty-600 text-white font-serif text-[10px] tracking-[0.25em] uppercase px-3 py-1.5">
            {venue.island}
          </span>
        </div>
        <div className="p-8 relative">
          <button onClick={onClose} className="absolute top-4 right-4 text-charcoal/50 hover:text-charcoal" aria-label="Close">
            <X className="w-6 h-6" />
          </button>
          <h3 className="font-serif text-2xl pr-8 leading-snug">{venue.name}</h3>
          <div className="mt-4 flex flex-wrap gap-4 text-sm text-charcoal/70">
            <span className="flex items-center gap-1.5"><Users className="w-4 h-4 text-liberty-600" />{venue.capacity}</span>
            <span className="flex items-center gap-1.5"><Sun className="w-4 h-4 text-liberty-600" />{venue.setting}</span>
            <span className="flex items-center gap-1.5"><MapPin className="w-4 h-4 text-liberty-600" />{venue.island}</span>
          </div>
          <p className="mt-5 text-charcoal/75 leading-relaxed">{venue.description}</p>
          <ul className="mt-6 grid gap-2.5">
            {venue.highlights.map((h) => (
              <li key={h} className="flex items-start gap-2.5 text-sm">
                <Check className="w-4 h-4 text-liberty-600 mt-0.5 shrink-0" /> {h}
              </li>
            ))}
          </ul>
          <p className="mt-6 text-xs text-charcoal/50">All events are subject to National Park Service approval. Capacities vary by layout.</p>
          <button onClick={() => onRequest(venue)} className="btn-primary w-full mt-6">Request Info</button>
        </div>
      </div>
    </div>
  );
}
