interface Props {
  eyebrow: string;
  title: string;
  subtitle?: string;
  light?: boolean;
  align?: 'center' | 'left';
}

export default function SectionHeading({ eyebrow, title, subtitle, light, align = 'center' }: Props) {
  const center = align === 'center';
  return (
    <div className={`reveal ${center ? 'text-center mx-auto' : ''} max-w-3xl mb-14`}>
      <div className={`engraved-rule ${center ? 'justify-center' : ''} ${light ? 'text-liberty-300' : ''} mb-5`}>
        <span className={`eyebrow ${light ? 'text-liberty-200' : ''}`}>{eyebrow}</span>
      </div>
      <h2 className={`font-serif text-3xl sm:text-4xl lg:text-5xl leading-tight ${light ? 'text-white' : 'text-charcoal'}`}>
        {title}
      </h2>
      {subtitle && (
        <p className={`mt-5 font-display text-xl sm:text-2xl leading-relaxed ${light ? 'text-white/75' : 'text-charcoal/65'}`}>
          {subtitle}
        </p>
      )}
    </div>
  );
}
