import { Link } from 'react-router-dom';
import { Phone, Sparkles } from 'lucide-react';
import { CONTACT, IMG } from '@/data/site';
import { openConcierge } from '@/lib/chatEvents';

export default function CtaBand() {
  return (
    <section className="relative py-28 overflow-hidden">
      <img src={IMG.plated} alt="" aria-hidden className="absolute inset-0 w-full h-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-r from-liberty-950/95 via-liberty-900/80 to-charcoal/40" />
      <div className="relative max-w-7xl mx-auto px-5 lg:px-8">
        <div className="max-w-2xl reveal">
          <div className="eyebrow text-liberty-200">A Culinary Experience Like No Other</div>
          <h2 className="font-serif text-white text-3xl sm:text-5xl mt-4 leading-tight">Celebrate Your Special Occasion</h2>
          <p className="mt-6 font-display text-xl text-white/80 leading-relaxed">
            Our Ellis Island Events service staff ensure your event runs smoothly from start to finish, with menus
            customized to your specifications — including any dietary restrictions — by our top NYC catering partners.
          </p>
          <div className="mt-9 flex flex-col sm:flex-row flex-wrap gap-4">
            <Link to="/inquire" className="btn-primary">Request a Quote</Link>
            <button type="button" onClick={() => openConcierge()} className="btn-outline-light"><Sparkles className="w-4 h-4" /> Ask Our AI Concierge</button>
            <a href={CONTACT.phoneHref} className="btn-outline-light"><Phone className="w-4 h-4" /> Call Now</a>
          </div>
        </div>
      </div>
    </section>
  );
}
