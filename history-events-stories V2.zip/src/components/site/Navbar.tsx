import { useEffect, useMemo, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { Menu, X, Phone } from 'lucide-react';
import { CONTACT, IMG } from '@/data/site';
import { PAGE_DEFAULTS, PAGE_SLUGS, pagePath } from '@/data/pages';
import { usePages } from '@/lib/pages';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();
  const { data } = usePages();

  const links = useMemo(() => {
    const pages = PAGE_SLUGS.map((s) => data?.[s] ?? PAGE_DEFAULTS[s]);
    return pages
      .filter((p) => p.show_in_nav && p.published && p.slug !== 'home')
      .sort((a, b) => a.sort_order - b.sort_order)
      .map((p) => ({ label: p.nav_label, to: pagePath(p.slug) }));
  }, [data]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => setOpen(false), [pathname]);
  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : '';
  }, [open]);

  const solid = scrolled || open;

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        solid ? 'bg-charcoal/95 backdrop-blur-md shadow-lg shadow-black/20 py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-5 lg:px-8 flex items-center justify-between gap-6">
        <Link to="/" className="flex items-center gap-3 group" aria-label="Ellis Island Events home">
          <img
            src={IMG.logo}
            alt="Evelyn Hill Inc. logo"
            className={`w-auto bg-white p-0.5 transition-all duration-500 ${solid ? 'h-12' : 'h-16'}`}
          />
          <div className="leading-tight">
            <div className="font-serif text-white text-base sm:text-lg tracking-[0.12em]">Ellis Island Events</div>
            <div className="font-serif text-liberty-300 text-[10px] tracking-[0.3em] uppercase">Evelyn Hill Inc.</div>
          </div>
        </Link>

        <nav className="hidden lg:flex items-center gap-7" aria-label="Primary">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              className={({ isActive }) =>
                `group relative font-serif text-[12px] tracking-[0.22em] uppercase transition-colors ${
                  isActive ? 'text-liberty-300' : 'text-white/85 hover:text-white'
                }`
              }
            >
              {({ isActive }) => (
                <>
                  {l.label}
                  <span className={`absolute -bottom-1.5 left-0 h-px bg-liberty-300 transition-all duration-300 ${isActive ? 'w-full' : 'w-0 group-hover:w-full'}`} />
                </>
              )}
            </NavLink>
          ))}
        </nav>

        <div className="hidden lg:flex items-center gap-5">
          <a href={CONTACT.phoneHref} className="flex items-center gap-2 text-white/85 hover:text-white text-sm">
            <Phone className="w-4 h-4 text-liberty-300" /> {CONTACT.phoneDisplay}
          </a>
          <Link to="/inquire" className="btn-primary !px-5 !py-2.5 !text-xs">Plan Your Event</Link>
        </div>

        <button
          className="lg:hidden text-white p-2 -mr-2"
          onClick={() => setOpen((o) => !o)}
          aria-label={open ? 'Close menu' : 'Open menu'}
          aria-expanded={open}
        >
          {open ? <X className="w-7 h-7" /> : <Menu className="w-7 h-7" />}
        </button>
      </div>

      <div className={`lg:hidden overflow-hidden transition-all duration-500 ${open ? 'max-h-[100vh] opacity-100' : 'max-h-0 opacity-0'}`}>
        <nav className="px-6 pt-6 pb-10 flex flex-col gap-1 border-t border-white/10 mt-2" aria-label="Mobile">
          <NavLink to="/" end className={({ isActive }) => `font-serif text-lg tracking-[0.18em] uppercase py-3 border-b border-white/10 ${isActive ? 'text-liberty-300' : 'text-white'}`}>
            Home
          </NavLink>
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              className={({ isActive }) => `font-serif text-lg tracking-[0.18em] uppercase py-3 border-b border-white/10 ${isActive ? 'text-liberty-300' : 'text-white'}`}
            >
              {l.label}
            </NavLink>
          ))}
          <a href={CONTACT.phoneHref} className="flex items-center gap-2 text-white/85 py-4">
            <Phone className="w-4 h-4 text-liberty-300" /> {CONTACT.phoneDisplay}
          </a>
          <Link to="/inquire" className="btn-primary mt-2">Plan Your Event</Link>
        </nav>
      </div>
    </header>
  );
}
