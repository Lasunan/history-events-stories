import { useMemo, useState } from 'react';
import { Users, ArrowUpRight } from 'lucide-react';
import { VENUES, type Venue, type Island } from '@/data/site';
import SectionHeading from './SectionHeading';
import VenueModal from './VenueModal';
import { useReveal } from '@/hooks/useReveal';

const FILTERS: ('All' | Island)[] = ['All', 'Ellis Island', 'Liberty Island'];

export default function Venues({ onRequest }: { onRequest: (venueName: string) => void }) {
  const [filter, setFilter] = useState<'All' | Island>('All');
  const [selected, setSelected] = useState<Venue | null>(null);
  const list = useMemo(() => (filter === 'All' ? VENUES : VENUES.filter((v) => v.island === filter)), [filter]);
  useReveal([filter]);

  const request = (v: Venue) => {
    setSelected(null);
    onRequest(v.name);
  };

  return (
    <section id="venues" className="py-24 lg:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-5 lg:px-8">
        <SectionHeading
          eyebrow="Event Venues"
          title="Spaces of Once-in-a-Lifetime Proportions"
          subtitle="Two islands, one National Monument — event spaces from 50 to 1,200 guests, indoors and under the stars."
        />

        <div className="flex flex-wrap justify-center gap-2 mb-12" role="tablist">
          {FILTERS.map((f) => {
            const count = f === 'All' ? VENUES.length : VENUES.filter((v) => v.island === f).length;
            return (
              <button
                key={f}
                role="tab"
                aria-selected={filter === f}
                onClick={() => setFilter(f)}
                className={`px-5 py-2.5 font-serif text-xs tracking-[0.2em] uppercase border transition ${
                  filter === f ? 'bg-liberty-600 border-liberty-600 text-white' : 'border-charcoal/15 text-charcoal/70 hover:border-liberty-600 hover:text-liberty-700'
                }`}
              >
                {f} <span className="opacity-60 ml-1">({count})</span>
              </button>
            );
          })}
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-7">
          {list.map((v, i) => (
            <article
              key={v.id}
              className="reveal group bg-ivory flex flex-col shadow-sm hover:shadow-2xl hover:shadow-liberty-900/15 hover:-translate-y-1.5 transition-all duration-500"
              style={{ transitionDelay: `${(i % 3) * 80}ms` }}
            >
              <button onClick={() => setSelected(v)} className="relative aspect-[4/3] overflow-hidden text-left" aria-label={`View ${v.name}`}>
                <img src={v.image} alt={v.name} loading="lazy" className="w-full h-full object-cover transition-transform duration-[1200ms] group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-charcoal/70 via-transparent to-transparent" />
                <span className="absolute top-4 left-4 bg-white/95 text-liberty-700 font-serif text-[10px] tracking-[0.25em] uppercase px-3 py-1.5">
                  {v.island}
                </span>
                <span className="absolute bottom-4 left-4 flex items-center gap-1.5 text-white text-sm">
                  <Users className="w-4 h-4" /> {v.capacity}
                </span>
                <span className="absolute bottom-4 right-4 w-9 h-9 bg-white/0 group-hover:bg-white text-white group-hover:text-charcoal border border-white/70 flex items-center justify-center transition">
                  <ArrowUpRight className="w-4 h-4" />
                </span>
              </button>
              <div className="p-6 flex flex-col flex-1">
                <div className="text-[11px] tracking-[0.2em] uppercase text-liberty-600 mb-2">{v.setting}</div>
                <h3 className="font-serif text-xl leading-snug">{v.name}</h3>
                <p className="mt-3 text-charcoal/70 leading-relaxed flex-1">{v.short}</p>
                <div className="mt-6 flex gap-3">
                  <button onClick={() => request(v)} className="btn-primary !px-4 !py-2.5 !text-[11px] flex-1">Request Info</button>
                  <button onClick={() => setSelected(v)} className="btn-outline !px-4 !py-2.5 !text-[11px]">Details</button>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>

      <VenueModal venue={selected} onClose={() => setSelected(null)} onRequest={request} />
    </section>
  );
}
