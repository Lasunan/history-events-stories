import { createClient } from '@supabase/supabase-js';


// Initialize database client
const supabaseUrl = 'https://nyuzdkuirrqdcfkwvmmv.databasepad.com';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImI2YjlkNDJlLTE4ZWItNDY0OS1hOTZlLWVlODEyZjBhMTU2NCJ9.eyJwcm9qZWN0SWQiOiJueXV6ZGt1aXJycWRjZmt3dm1tdiIsInJvbGUiOiJhbm9uIiwiaWF0IjoxNzkwMzY3MzQwLCJleHAiOjIxMDU3MjczNDAsImlzcyI6ImZhbW91cy5kYXRhYmFzZXBhZCIsImF1ZCI6ImZhbW91cy5jbGllbnRzIn0.DbFVRu_V9ycB_u-73renH7gZSuYp6qhcEbL1oW8COKY';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };