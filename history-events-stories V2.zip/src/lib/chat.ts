// Shared logic for the AI Event Concierge chat widget and the /admin chat viewer.
import { supabase } from '@/lib/supabase';
import { subscribeToCrm, isValidEmail } from '@/lib/crm';
import {
  VENUES, EVENT_TYPES, FAQS, INQUIRY_EVENT_TYPES, ENHANCEMENTS, CONTACT, TEAM, STATS, PATTI_PHONE, RFQ_PATH,
} from '@/data/site';

export const CHAT_ASSISTANT = {
  name: 'Patti',
  title: 'AI Event Concierge',
  avatar: TEAM[0].image, // Patti Golden's portrait (single source: src/data/site.ts)
  greeting:
    "Welcome to Ellis Island & Liberty Island Events! I'm Patti's AI event concierge. Whether you're dreaming up a gala, fundraiser or corporate meeting, I can walk you through venues, logistics and next steps. What are you planning?",
};

export const STARTER_PROMPTS = [
  'Which venues fit 300 guests?',
  'How do I get a quote?',
  'How do guests get to the island?',
  'Is my date available?',
];

// ---------- No-pricing policy ----------
// The concierge never states prices. Every cost question is redirected to the RFQ form,
// Patti's phone, or WhatsApp (when configured in CONTACT.whatsappUrl).

/** Detects any monetary figure: "$9,000", "9k", "12,000 dollars", "USD 500". */
const MONEY_RE = /\$\s?\d|\d[\d,.]*\s?(?:k\b|dollars?\b|usd\b)|\busd\s?\d/i;
export const mentionsPrice = (s: string) => MONEY_RE.test(s);

/** Contact options sentence used whenever pricing comes up. */
export function pricingRedirect(): string {
  const wa = CONTACT.whatsappUrl ? `, or message her on [WhatsApp](${CONTACT.whatsappUrl})` : '';
  return `Every event here is custom-quoted, so I don't share pricing in chat. For a tailored estimate, please fill out our [Request a Quote form](${RFQ_PATH}) — or call Patti directly at **${PATTI_PHONE.display}**${wa}.`;
}

/** Remove monetary figures from knowledge text so the model never sees prices to quote. */
function redactPricing(text: string): string {
  const noParens = text.replace(/\s?\([^)]*\$[^)]*\)/g, '');
  const kept = noParens.split(/(?<=[.!?])\s+/).filter((s) => !mentionsPrice(s));
  return kept.join(' ');
}

/** Knowledge base sent to the edge function, built from the single source of truth in site.ts. */
export function buildKnowledge(): string {
  const venues = VENUES.map(
    (v) => `- ${v.name} (${v.island}; ${v.setting}; capacity: ${v.capacity}). ${v.description} Highlights: ${v.highlights.join(', ')}. Page: /venues`
  ).join('\n');
  const events = EVENT_TYPES.map((e) => `- ${e.title}: ${e.text}`).join('\n');
  const extras = ENHANCEMENTS.map((e) => `- ${e.title}: ${e.text}`).join('\n');
  const faqs = FAQS.map((f) => {
    const a = redactPricing(f.a);
    const priced = a !== f.a;
    return `Q: ${f.q}\nA: ${a}${priced ? ' [Pricing details: provided only in a tailored proposal — send the visitor to the RFQ form.]' : ''}`;
  }).join('\n\n');
  const stats = STATS.map((s) => `${s.value} ${s.label}`).join('; ');
  const team = TEAM.map((t) => `${t.name}, ${t.role} (${t.email})`).join('; ');
  const whatsapp = CONTACT.whatsappUrl ? `WhatsApp Business (Patti's mobile): ${CONTACT.whatsappUrl}` : 'WhatsApp: not yet available in chat — do not mention it.';
  return `ORGANIZATION: Statue of Liberty & Ellis Island Events, the Special Events division of Evelyn Hill Inc. (family-owned NPS concessioner since 1931). Key facts: ${stats}.
TEAM: ${team}. Email: ${CONTACT.email}. Corporate: ${CONTACT.corporateEmail}. Address: ${CONTACT.address}.
CONTACT CHANNELS FOR QUOTES (always offer these for any cost question):
- RFQ / Request a Quote form: ${RFQ_PATH} (preferred — link as [Request a Quote form](${RFQ_PATH}))
- Patti's direct phone: ${PATTI_PHONE.display}
- ${whatsapp}
- Book a call with the team: ${CONTACT.bookingUrl}

VENUE NAMES (use exactly):
${venues}

EVENT TYPES:
${events}

INQUIRY EVENT TYPES (use exactly for lead.event_type): ${INQUIRY_EVENT_TYPES.join(' | ')}

ENHANCEMENTS:
${extras}

PLANNING FAQ:
${faqs}`;
}


const STORAGE_KEY = 'eie-ai-chat-v1';

const newSessionId = () =>
  (typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`);

export function freshChatState(): ChatState {
  return {
    sessionId: newSessionId(),
    messages: [{ role: 'assistant', content: CHAT_ASSISTANT.greeting, at: new Date().toISOString() }],
    lead: {},
    subscribedEmail: null,
    inquiryId: null,
    suggestions: STARTER_PROMPTS,
  };
}

export function loadChatState(): ChatState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const s = JSON.parse(raw) as ChatState;
      if (s?.sessionId && Array.isArray(s.messages) && s.messages.length) return s;
    }
  } catch { /* ignore */ }
  return freshChatState();
}

export function saveChatState(s: ChatState) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(s)); } catch { /* ignore */ }
}

/** Merge new lead info from the model without letting nulls erase known values. */
export function mergeLead(prev: ChatLead, next: ChatLead | undefined): ChatLead {
  if (!next) return prev;
  const out: ChatLead = { ...prev };
  (Object.keys(next) as (keyof ChatLead)[]).forEach((k) => {
    const v = next[k];
    if (k === 'sms_opt_in') { out.sms_opt_in = prev.sms_opt_in === true || v === true; return; }
    if (v === null || v === undefined || v === '') return;
    if (k === 'guest_count') {
      const n = typeof v === 'number' ? v : parseInt(String(v).replace(/[^\d]/g, ''), 10);
      if (Number.isFinite(n) && n > 0) out.guest_count = n;
      return;
    }
    if (k === 'event_date') { if (/^\d{4}-\d{2}-\d{2}$/.test(String(v))) out.event_date = String(v); return; }
    if (k === 'event_type') { out.event_type = INQUIRY_EVENT_TYPES.includes(String(v)) ? String(v) : 'Other'; return; }
    if (k === 'venue') { if (VENUES.some((x) => x.name === v)) out.venue = String(v); return; }
    (out as Record<string, unknown>)[k] = String(v).trim();
  });
  return out;
}

export const leadHasContact = (l: ChatLead) => !!(l.first_name && l.email && isValidEmail(l.email));
export const leadIsQualified = (l: ChatLead) => leadHasContact(l) && !!(l.event_date || l.guest_count);

/** Ask the edge function for the next assistant reply. */
export async function askConcierge(messages: ChatMessage[], lead: ChatLead, page: string) {
  const { data, error } = await supabase.functions.invoke('ellis-chat', {
    body: {
      messages: messages.map(({ role, content }) => ({ role, content })),
      lead,
      page,
      knowledge: buildKnowledge(),
      pricingRedirect: pricingRedirect(),
    },
  });
  if (error || !data || data.error) throw new Error(data?.error || error?.message || 'Assistant unavailable');
  const result = data as { reply: string; lead?: ChatLead; suggestions?: string[] };
  // Client-side no-pricing guard (backup to the server guard): drop any sentence with a price
  // and replace it with the RFQ / phone / WhatsApp redirect.
  if (typeof result.reply === 'string' && mentionsPrice(result.reply)) {
    const kept = result.reply.split(/(?<=[.!?])\s+/).filter((s) => !mentionsPrice(s));
    const redirect = pricingRedirect();
    result.reply = [...kept, kept.join(' ').includes(RFQ_PATH) ? '' : redirect].filter(Boolean).join(' ') || redirect;
  }
  if (Array.isArray(result.suggestions)) result.suggestions = result.suggestions.filter((s) => !mentionsPrice(String(s)));
  return result;
}


/** Subscribe the contact to the CRM once a valid email is known (source: ai-chat). */
export async function syncCrm(lead: ChatLead) {
  if (!lead.email || !isValidEmail(lead.email)) return;
  await subscribeToCrm({
    email: lead.email.trim(),
    name: [lead.first_name, lead.last_name].filter(Boolean).join(' ') || undefined,
    phone: lead.phone || undefined,
    sms_opt_in: lead.sms_opt_in === true,
    source: 'ai-chat',
    tags: ['ai-chat', 'event-inquiry', ...(lead.event_type ? [lead.event_type] : [])],
  });
}

/** Create the event_inquiries row once (anon insert allowed; id generated client-side). */
export async function createInquiryFromLead(lead: ChatLead, transcript: ChatMessage[]): Promise<string | null> {
  const id = newSessionId();
  const summary = transcript
    .filter((m) => m.role === 'user')
    .map((m) => m.content)
    .join(' / ')
    .slice(0, 1500);
  const { error } = await supabase.from('event_inquiries').insert({
    id,
    first_name: lead.first_name || 'Chat',
    last_name: lead.last_name || 'Visitor',
    email: lead.email!.trim(),
    phone: lead.phone || null,
    company: lead.company || null,
    event_type: lead.event_type || 'Other',
    venue: lead.venue || null,
    event_date: lead.event_date || null,
    guest_count: lead.guest_count || null,
    sms_opt_in: lead.sms_opt_in === true,
    message: `[Captured by AI chat concierge] Visitor said: ${summary}`,
  });
  if (error) { console.error('Inquiry insert failed', error); return null; }
  return id;
}

/** Persist the transcript via a SECURITY DEFINER RPC (visitors cannot read other chats). */
export async function persistTranscript(s: ChatState, page: string) {
  const { error } = await supabase.rpc('save_chat_conversation', {
    p_session_id: s.sessionId,
    p_messages: s.messages,
    p_lead: s.lead,
    p_inquiry_id: s.inquiryId,
    p_page_path: page,
  });
  if (error) console.error('Transcript save failed', error);
}

// ---------- Admin types ----------
export const CHAT_STATUSES = ['Open', 'Reviewed', 'Archived'] as const;
export type ChatStatus = (typeof CHAT_STATUSES)[number];

export interface ChatConversation {
  id: string;
  session_id: string;
  visitor_name: string | null;
  visitor_email: string | null;
  visitor_phone: string | null;
  company: string | null;
  event_type: string | null;
  venue: string | null;
  event_date: string | null;
  guest_count: number | null;
  sms_opt_in: boolean;
  messages: ChatMessage[];
  message_count: number;
  lead_captured: boolean;
  inquiry_id: string | null;
  page_path: string | null;
  status: ChatStatus;
  created_at: string;
  updated_at: string;
}
