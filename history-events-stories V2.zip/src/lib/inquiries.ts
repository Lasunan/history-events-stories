// Shared types, constants and helpers for the admin inquiries dashboard.

export const INQUIRY_STATUSES = ['New', 'Contacted', 'Proposal Sent', 'Booked', 'Lost'] as const;
export type InquiryStatus = (typeof INQUIRY_STATUSES)[number];

export const STATUS_STYLES: Record<InquiryStatus, { badge: string; dot: string }> = {
  New: { badge: 'bg-sky-50 text-sky-700 ring-sky-200', dot: 'bg-sky-500' },
  Contacted: { badge: 'bg-amber-50 text-amber-700 ring-amber-200', dot: 'bg-amber-500' },
  'Proposal Sent': { badge: 'bg-violet-50 text-violet-700 ring-violet-200', dot: 'bg-violet-500' },
  Booked: { badge: 'bg-liberty-50 text-liberty-700 ring-liberty-200', dot: 'bg-liberty-600' },
  Lost: { badge: 'bg-zinc-100 text-zinc-600 ring-zinc-200', dot: 'bg-zinc-400' },
};

export interface Inquiry {
  id: string;
  created_at: string;
  updated_at: string;
  first_name: string;
  last_name: string;
  email: string;
  phone: string | null;
  company: string | null;
  event_type: string;
  venue: string | null;
  event_date: string | null;
  guest_count: number | null;
  message: string | null;
  sms_opt_in: boolean | null;
  status: InquiryStatus;
}

export interface InquiryNote {
  id: string;
  inquiry_id: string;
  author_email: string | null;
  body: string;
  created_at: string;
}

export interface InquiryFilters {
  search: string;
  eventType: string;
  venue: string;
  status: string;
  dateFrom: string;
  dateTo: string;
}

export const EMPTY_FILTERS: InquiryFilters = { search: '', eventType: '', venue: '', status: '', dateFrom: '', dateTo: '' };

export function applyFilters(list: Inquiry[], f: InquiryFilters): Inquiry[] {
  const q = f.search.trim().toLowerCase();
  return list.filter((i) => {
    if (f.status && i.status !== f.status) return false;
    if (f.eventType && i.event_type !== f.eventType) return false;
    if (f.venue === '__none' ? !!i.venue : f.venue && i.venue !== f.venue) return false;
    if (f.dateFrom && (!i.event_date || i.event_date < f.dateFrom)) return false;
    if (f.dateTo && (!i.event_date || i.event_date > f.dateTo)) return false;
    if (q) {
      const hay = [i.first_name, i.last_name, i.email, i.phone, i.company, i.message, i.venue, i.event_type]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });
}

export const fmtDate = (d: string | null, withTime = false) => {
  if (!d) return '—';
  // event_date is a plain YYYY-MM-DD (sometimes serialized as midnight UTC); parse as local date to avoid timezone shift.
  const plain = /^\d{4}-\d{2}-\d{2}(T00:00:00(\.000)?(Z|\+00:00))?$/.test(d) ? d.slice(0, 10) : null;
  const date = plain ? new Date(`${plain}T00:00:00`) : new Date(d);
  return date.toLocaleDateString('en-US', {
    month: 'short', day: 'numeric', year: 'numeric',
    ...(withTime ? { hour: 'numeric', minute: '2-digit' } : {}),
  });
};

const csvCell = (v: unknown) => {
  const s = v === null || v === undefined ? '' : String(v);
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

export function exportInquiriesCsv(list: Inquiry[], notes: Record<string, InquiryNote[]> = {}) {
  const headers = [
    'Submitted', 'Status', 'First Name', 'Last Name', 'Email', 'Phone', 'SMS Opt-In', 'Company',
    'Event Type', 'Venue', 'Event Date', 'Guests', 'Message', 'Internal Notes', 'Last Updated', 'ID',
  ];
  const rows = list.map((i) => [
    new Date(i.created_at).toISOString(), i.status, i.first_name, i.last_name, i.email, i.phone,
    i.sms_opt_in ? 'Yes' : 'No', i.company, i.event_type, i.venue, i.event_date, i.guest_count, i.message,
    (notes[i.id] || []).map((n) => `[${new Date(n.created_at).toLocaleString()} ${n.author_email ?? ''}] ${n.body}`).join(' | '),
    new Date(i.updated_at).toISOString(), i.id,
  ]);
  const csv = [headers, ...rows].map((r) => r.map(csvCell).join(',')).join('\r\n');
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `ellis-island-inquiries-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
