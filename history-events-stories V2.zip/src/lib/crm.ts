export interface SubscribePayload {
  email: string;
  name?: string;
  phone?: string;
  sms_opt_in?: boolean;
  source: string;
  tags: string[];
}

export async function subscribeToCrm(payload: SubscribePayload) {
  const res = await fetch('https://famous.ai/api/crm/6ab6d645384aa31e9a27da77/subscribe', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: payload.email,
      name: payload.name || undefined,
      phone: payload.phone?.trim() ? payload.phone.trim() : undefined,
      sms_opt_in: payload.sms_opt_in === true,
      source: payload.source,
      tags: payload.tags,
    }),
  });
  if (!res.ok) throw new Error('Subscription failed');
  return res.json().catch(() => ({}));
}

export const isValidEmail = (v: string) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim());
