import { useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { PAGE_DEFAULTS, PAGE_SLUGS, type PageSlug, type SitePage } from '@/data/pages';

export const PAGES_QUERY_KEY = ['site_pages'];

const TEXT_FIELDS: (keyof SitePage)[] = [
  'nav_label', 'seo_title', 'meta_description', 'hero_eyebrow', 'hero_title', 'hero_subtitle', 'hero_image', 'body',
];

/** Merge a DB row over the code defaults (empty DB values fall back to defaults). */
export function mergePage(slug: PageSlug, row?: Partial<SitePage> | null): SitePage {
  const base = { ...PAGE_DEFAULTS[slug] };
  if (!row) return base;
  const out: SitePage = { ...base };
  TEXT_FIELDS.forEach((k) => {
    const v = row[k];
    if (typeof v === 'string' && v.trim() !== '') (out as Record<string, unknown>)[k] = v;
  });
  if (typeof row.show_in_nav === 'boolean') out.show_in_nav = row.show_in_nav;
  if (typeof row.published === 'boolean') out.published = row.published;
  if (typeof row.sort_order === 'number') out.sort_order = row.sort_order;
  out.updated_at = row.updated_at ?? null;
  out.updated_by = row.updated_by ?? null;
  return out;
}

export async function fetchPages(): Promise<Record<PageSlug, SitePage>> {
  const { data } = await supabase.from('site_pages').select('*');
  const rows = (data as SitePage[] | null) || [];
  const map = {} as Record<PageSlug, SitePage>;
  PAGE_SLUGS.forEach((slug) => {
    map[slug] = mergePage(slug, rows.find((r) => r.slug === slug));
  });
  // Unpublished rows aren't returned to the public; mark them hidden.
  if (rows.length) PAGE_SLUGS.forEach((s) => { if (!rows.find((r) => r.slug === s)) map[s].published = false; });
  return map;
}

export function usePages() {
  return useQuery({ queryKey: PAGES_QUERY_KEY, queryFn: fetchPages, staleTime: 60_000 });
}

export function usePage(slug: PageSlug): SitePage {
  const { data } = usePages();
  return data?.[slug] ?? PAGE_DEFAULTS[slug];
}

export function useInvalidatePages() {
  const qc = useQueryClient();
  return () => qc.invalidateQueries({ queryKey: PAGES_QUERY_KEY });
}

/** Sets document title + meta description for the current page. */
export function useSeo(page: SitePage) {
  useEffect(() => {
    document.title = page.seo_title || page.hero_title;
    let meta = document.querySelector('meta[name="description"]') as HTMLMetaElement | null;
    if (!meta) {
      meta = document.createElement('meta');
      meta.name = 'description';
      document.head.appendChild(meta);
    }
    meta.content = page.meta_description || '';
  }, [page.seo_title, page.hero_title, page.meta_description]);
}

export async function savePage(page: SitePage, email: string) {
  const payload = {
    slug: page.slug,
    nav_label: page.nav_label,
    seo_title: page.seo_title,
    meta_description: page.meta_description,
    hero_eyebrow: page.hero_eyebrow,
    hero_title: page.hero_title,
    hero_subtitle: page.hero_subtitle,
    hero_image: page.hero_image,
    body: page.body,
    show_in_nav: page.show_in_nav,
    sort_order: page.sort_order,
    published: page.published,
    updated_by: email,
    updated_at: new Date().toISOString(),
  };
  return supabase.from('site_pages').upsert(payload, { onConflict: 'slug' }).select().single();
}

export async function uploadSiteImage(file: File): Promise<string> {
  const ext = file.name.split('.').pop()?.toLowerCase() || 'jpg';
  const path = `pages/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
  const { error } = await supabase.storage.from('site-media').upload(path, file, { cacheControl: '3600', upsert: false });
  if (error) throw error;
  return supabase.storage.from('site-media').getPublicUrl(path).data.publicUrl;
}
