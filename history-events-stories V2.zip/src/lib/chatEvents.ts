export const OPEN_CHAT_EVENT = 'eie:open-chat';

/** Open the AI concierge from anywhere; optionally send a starter prompt. */
export function openConcierge(prompt?: string) {
  window.dispatchEvent(new CustomEvent(OPEN_CHAT_EVENT, { detail: { prompt } }));
}
