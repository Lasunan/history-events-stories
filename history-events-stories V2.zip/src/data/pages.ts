import { IMG } from './site';

// Every routable page on the site. Content here is the FALLBACK — admins override it
// from /admin → Pages (stored in the `site_pages` table).
export type PageSlug = 'home' | 'venues' | 'events' | 'gallery' | 'about' | 'tours' | 'faq' | 'inquire';

export interface SitePage {
  slug: PageSlug;
  nav_label: string;
  seo_title: string;
  meta_description: string;
  hero_eyebrow: string;
  hero_title: string;
  hero_subtitle: string;
  hero_image: string;
  body: string;
  show_in_nav: boolean;
  sort_order: number;
  published: boolean;
  updated_by?: string | null;
  updated_at?: string | null;
}

export const pagePath = (slug: PageSlug) => (slug === 'home' ? '/' : `/${slug}`);

export const PAGE_DEFAULTS: Record<PageSlug, SitePage> = {
  home: {
    slug: 'home', nav_label: 'Home', sort_order: 0, show_in_nav: false, published: true,
    seo_title: 'Ellis Island Events | Private Events at Ellis Island & the Statue of Liberty',
    meta_description: 'Host galas, fundraisers, product launches and corporate events with exclusive use of Ellis Island and Liberty Island. 95 years of Evelyn Hill hospitality.',
    hero_eyebrow: 'Ellis Island & Liberty Island · New York',
    hero_title: 'A Monumental Venue for Memorable Gatherings',
    hero_subtitle: 'Exclusive use of a National Monument, spectacular views of Lady Liberty and the Manhattan skyline — backed by 95 years of Evelyn Hill hospitality.',
    hero_image: IMG.hero,
    body: '',
  },
  venues: {
    slug: 'venues', nav_label: 'Venues', sort_order: 1, show_in_nav: true, published: true,
    seo_title: 'Event Venues on Ellis Island & Liberty Island | Ellis Island Events',
    meta_description: 'Explore the Great Hall, Torch Gallery, Green Roof, waterfront lawns and more — ten one-of-a-kind event spaces in New York Harbor.',
    hero_eyebrow: 'Event Spaces',
    hero_title: 'Ten Venues. Two Islands. One Unforgettable Evening.',
    hero_subtitle: 'From the vaulted Registry Room to dinner beside the original 1886 torch, every space is yours exclusively.',
    hero_image: IMG.registryRoom,
    body: '',
  },
  events: {
    slug: 'events', nav_label: 'Events', sort_order: 2, show_in_nav: true, published: true,
    seo_title: 'Corporate Galas, Fundraisers & Private Events | Ellis Island Events',
    meta_description: 'Corporate galas, fundraisers, meetings, product launches, holiday parties and milestone family events at the Statue of Liberty and Ellis Island.',
    hero_eyebrow: 'Event Types',
    hero_title: 'Celebrate Where America Began',
    hero_subtitle: 'Galas, fundraisers, launches and milestone celebrations — each approved by the National Park Service and planned by our team.',
    hero_image: IMG.greatHallGala,
    body: '',
  },
  gallery: {
    slug: 'gallery', nav_label: 'Gallery', sort_order: 3, show_in_nav: true, published: true,
    seo_title: 'Event Gallery | Ellis Island Events',
    meta_description: 'Photos of galas, corporate events, fireworks and celebrations held on Ellis Island and Liberty Island.',
    hero_eyebrow: 'Gallery',
    hero_title: 'Moments Made Monumental',
    hero_subtitle: 'A look inside events hosted beneath Lady Liberty and in the halls of Ellis Island.',
    hero_image: IMG.fireworksReal,
    body: '',
  },
  about: {
    slug: 'about', nav_label: 'About', sort_order: 4, show_in_nav: true, published: true,
    seo_title: 'About Evelyn Hill Inc. | Ellis Island Events',
    meta_description: 'Evelyn Hill Inc. — a third-generation family-owned National Park Service concessioner at the Statue of Liberty since 1931.',
    hero_eyebrow: 'About Us',
    hero_title: '95 Years of Hospitality at the Statue of Liberty',
    hero_subtitle: 'A family-owned concessioner and your trusted liaison to the National Park Service.',
    hero_image: IMG.torchSunset,
    body: '',
  },
  tours: {
    slug: 'tours', nav_label: 'Tours', sort_order: 5, show_in_nav: true, published: true,
    seo_title: 'Virtual Venue Tours | Ellis Island Events',
    meta_description: 'Take a virtual tour of Ellis Island and Liberty Island event spaces, or schedule a planning call with our team.',
    hero_eyebrow: 'Virtual Tours',
    hero_title: 'Walk the Islands Before You Arrive',
    hero_subtitle: 'Explore every venue online, then schedule a planning call or an in-person site visit.',
    hero_image: IMG.ellisExterior,
    body: '',
  },
  faq: {
    slug: 'faq', nav_label: 'FAQ', sort_order: 6, show_in_nav: true, published: true,
    seo_title: 'Event Planning FAQ | Ellis Island Events',
    meta_description: 'Costs, ferries, security, permits, timing and insurance — answers to common questions about hosting an event on Ellis Island and Liberty Island.',
    hero_eyebrow: 'Planning Questions',
    hero_title: 'Frequently Asked Questions',
    hero_subtitle: 'Permits, ferries, timing and costs — everything you need to know before you book.',
    hero_image: IMG.ferry,
    body: '',
  },
  inquire: {
    slug: 'inquire', nav_label: 'Plan Your Event', sort_order: 7, show_in_nav: false, published: true,
    seo_title: 'Request a Quote | Ellis Island Events',
    meta_description: 'Inquire about available dates for your event on Ellis Island or Liberty Island. Our team responds within 24 hours.',
    hero_eyebrow: 'Book Your Special Event',
    hero_title: 'Plan Your Monumental Event',
    hero_subtitle: 'Tell us about your vision — our team responds within 24 hours with availability and a customized quote.',
    hero_image: IMG.libertyNight,
    body: '',
  },
};

export const PAGE_SLUGS = Object.keys(PAGE_DEFAULTS) as PageSlug[];
