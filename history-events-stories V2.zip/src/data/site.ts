// Single source of truth for all Ellis Island Events / Evelyn Hill Inc. site content.

export const IMG = {
  logo: 'https://d64gsuwffb70l.cloudfront.net/6ab6d645384aa31e9a27da77_1790367724821_732617eb.webp',
  medallion95: 'https://d64gsuwffb70l.cloudfront.net/6ab6d645384aa31e9a27da77_1790367790829_bfdb6bc8.webp',
  hero: 'https://d64gsuwffb70l.cloudfront.net/6ab6d645384aa31e9a27da77_1790367499791_2c7a1560.jpg',
  // Live-site photography (optimized)
  registryRoom: 'https://d64gsuwffb70l.cloudfront.net/6ab6d645384aa31e9a27da77_1790367790594_518bbde2.webp',
  libertyNight: 'https://d64gsuwffb70l.cloudfront.net/6ab6d645384aa31e9a27da77_1790367790670_2b73014a.webp',
  conferenceRoom: 'https://d64gsuwffb70l.cloudfront.net/6ab6d645384aa31e9a27da77_1790367791095_2a95a3c0.webp',
  museum: 'https://d64gsuwffb70l.cloudfront.net/6ab6d645384aa31e9a27da77_1790367790625_3b52882d.webp',
  fireworksReal: 'https://d64gsuwffb70l.cloudfront.net/6ab6d645384aa31e9a27da77_1790367790790_2d6c59e2.webp',
  corporateEllis: 'https://d64gsuwffb70l.cloudfront.net/6ab6d645384aa31e9a27da77_1790367790568_2c57865d.webp',
  celebratoryHall: 'https://d64gsuwffb70l.cloudfront.net/6ab6d645384aa31e9a27da77_1790367791192_d5dabaee.webp',
  torchSunset: 'https://d64gsuwffb70l.cloudfront.net/6ab6d645384aa31e9a27da77_1790367791018_ed9bce2c.webp',
  // Editorial imagery
  greatHallGala: 'https://d64gsuwffb70l.cloudfront.net/6ab6d645384aa31e9a27da77_1790367514246_f0388cfe.jpg',
  lawnReception: 'https://d64gsuwffb70l.cloudfront.net/6ab6d645384aa31e9a27da77_1790367528995_1656bc24.jpg',
  balconyMeeting: 'https://d64gsuwffb70l.cloudfront.net/6ab6d645384aa31e9a27da77_1790367543553_ebfed837.jpg',
  torchDinner: 'https://d64gsuwffb70l.cloudfront.net/6ab6d645384aa31e9a27da77_1790367565245_7d3f61fd.jpg',
  greenRoof: 'https://d64gsuwffb70l.cloudfront.net/6ab6d645384aa31e9a27da77_1790367580770_57d97ef7.jpg',
  fireworks: 'https://d64gsuwffb70l.cloudfront.net/6ab6d645384aa31e9a27da77_1790367595377_78e0d1bb.jpg',
  ellisExterior: 'https://d64gsuwffb70l.cloudfront.net/6ab6d645384aa31e9a27da77_1790367610183_ce2d1fe6.jpg',
  theater: 'https://d64gsuwffb70l.cloudfront.net/6ab6d645384aa31e9a27da77_1790367631860_623587d1.jpg',
  ferry: 'https://d64gsuwffb70l.cloudfront.net/6ab6d645384aa31e9a27da77_1790367647269_f20fceec.jpg',
  plated: 'https://d64gsuwffb70l.cloudfront.net/6ab6d645384aa31e9a27da77_1790367662284_ebcbeaab.jpg',
  awards: 'https://d64gsuwffb70l.cloudfront.net/6ab6d645384aa31e9a27da77_1790367679211_c017d548.jpg',
  family: 'https://d64gsuwffb70l.cloudfront.net/6ab6d645384aa31e9a27da77_1790367701205_96071359.jpg',
  fundraiser: 'https://d64gsuwffb70l.cloudfront.net/6ab6d645384aa31e9a27da77_1790367718909_9f838828.jpg',
  patti: 'https://d64gsuwffb70l.cloudfront.net/6ab6d645384aa31e9a27da77_1790367724776_ce711c60.webp',
  tara: 'https://d64gsuwffb70l.cloudfront.net/6ab6d645384aa31e9a27da77_1790367724778_bca77147.webp',
};

export const CONTACT = {
  phoneDisplay: '(212) 344-0996',
  phoneHref: 'tel:+12123440996',
  // Patti's direct mobile. Leave blank to fall back to the main events line above.
  pattiCellDisplay: '',
  pattiCellHref: '', // e.g. 'tel:+19175551234'
  // WhatsApp Business link for Patti's mobile, e.g. 'https://wa.me/19175551234'.
  // When set, WhatsApp buttons appear on the RFQ form (/inquire) and in the AI chat.
  whatsappUrl: '',
  email: 'pgolden@ehillgroup.com',
  corporateEmail: 'corporate@ellisisland-events.com',
  address: '1 Liberty Island – Ellis Island, Jersey City, NJ 07305',
  mapsUrl: 'https://maps.google.com/?cid=14943158205799409237',
  bookingUrl:
    'https://famous.ai/api/crm/6ab6d645384aa31e9a27da77/calendar/public?calendarId=9b6abd8e-4400-4157-b5a3-59b571c838d1&view=booking',
  parentSite: 'https://thestatueofliberty.com/',
};

/** Patti's direct line (her mobile if configured, otherwise the main events line). */
export const PATTI_PHONE = {
  display: CONTACT.pattiCellDisplay || CONTACT.phoneDisplay,
  href: CONTACT.pattiCellHref || CONTACT.phoneHref,
  isCell: !!CONTACT.pattiCellHref,
};

/** Where the AI concierge sends every pricing / quote question. */
export const RFQ_PATH = '/inquire';


export const SOCIALS = [
  { name: 'Facebook', href: 'https://www.facebook.com/EllisIslandEvents/' },
  { name: 'Instagram', href: 'https://www.instagram.com/statue_ellis/' },
  { name: 'LinkedIn', href: 'https://www.linkedin.com/company/statue-of-liberty-and-ellis-island-events' },
  { name: 'YouTube', href: 'https://www.youtube.com/channel/UCaKeGa7Da2hkycWfI_kJeQQ' },
] as const;

// Navigation links are derived from routed pages in src/data/pages.ts (editable in /admin → Pages).

export type Island = 'Ellis Island' | 'Liberty Island';

export interface Venue {
  id: string;
  name: string;
  island: Island;
  image: string;
  capacity: string;
  setting: 'Indoor' | 'Outdoor' | 'Indoor & Outdoor';
  short: string;
  description: string;
  highlights: string[];
}

export const VENUES: Venue[] = [
  {
    id: 'great-hall',
    name: 'The Great Hall — Registry Room',
    island: 'Ellis Island',
    image: IMG.registryRoom,
    capacity: '50 – 1,200 guests',
    setting: 'Indoor',
    short: 'The legendary vaulted hall where 12 million immigrants began their American story.',
    description:
      'For over 100 years, Ellis Island has stood as the symbol of a new beginning for millions of Americans. Host your gala beneath the iconic Guastavino-tiled ceiling of the Registry Room — with exclusive use of a National Monument and National Park Rangers on site.',
    highlights: ['Exclusive use of the Monument', 'Up to 13,000 sq ft of interior space', 'Manhattan skyline views', 'Museum galleries open to guests'],
  },
  {
    id: 'celebratory-hall',
    name: 'Celebratory Hall',
    island: 'Ellis Island',
    image: IMG.celebratoryHall,
    capacity: 'Receptions & seated dinners',
    setting: 'Indoor',
    short: 'A graceful, light-filled hall for dinners, award ceremonies and receptions.',
    description:
      'Whether it be an intimate cocktail party, a lavish corporate gathering, incentive group or awards ceremony, the Celebratory Hall offers a refined backdrop steeped in history — with menus customized by our top NYC catering partners.',
    highlights: ['Flexible layouts', 'Custom catering menus', 'Stage & AV ready', 'Adjacent to museum exhibits'],
  },
  {
    id: 'conference-room',
    name: 'Conference Room & Private Balcony',
    island: 'Ellis Island',
    image: IMG.conferenceRoom,
    capacity: 'Day events up to 100 guests',
    setting: 'Indoor',
    short: 'Strategize on the 3rd floor of the Museum, overlooking the Great Hall.',
    description:
      'The Conference Room located on the 3rd floor of the Museum provides a unique opportunity to strategize with your team while immersed in the historical and inspiring comfort overlooking the Great Hall. Dine on the private balcony while retracing the steps of millions of immigrants on their search for the American Dream.',
    highlights: ['Board & theater seating', 'Private balcony dining', 'Overlooks the Great Hall', 'Ideal for offsites & retreats'],
  },
  {
    id: 'museum-galleries',
    name: 'Ellis Island Museum Galleries',
    image: IMG.fundraiser,
    island: 'Ellis Island',
    capacity: 'Cocktail receptions',
    setting: 'Indoor',
    short: 'Let guests explore the exhibits of the former immigration station during your event.',
    description:
      'The exhibits and galleries of this former immigration station are open to your guests so they can experience what over 12 million immigrants did between 1892 and 1954 in search of the American Dream — the perfect cocktail-hour companion.',
    highlights: ['Galleries open exclusively for you', 'Wall of Honor access', 'Ranger-led moments', 'Ideal for fundraisers'],
  },
  {
    id: 'ellis-lawn',
    name: 'Waterfront Lawn & Promenade',
    island: 'Ellis Island',
    image: IMG.lawnReception,
    capacity: 'Up to 1,200 guests',
    setting: 'Outdoor',
    short: 'Host guests under the stars, overlooking the Statue of Liberty.',
    description:
      'This National Monument is yours exclusively — so you decide the location. Host your guests outdoors under the stars overlooking the Statue of Liberty and the New York City skyline. Fireworks can add the perfect finale.',
    highlights: ['Statue of Liberty views', 'Tented options', 'Firework finale available', 'Weather & NPS dependent'],
  },
  {
    id: 'family-history-center',
    name: 'American Family History Center',
    island: 'Ellis Island',
    image: IMG.ellisExterior,
    capacity: 'Private add-on experience',
    setting: 'Indoor',
    short: 'Research ancestors among 65 million passenger records during your event.',
    description:
      'Welcome to the Ellis Island Passenger Search database, home to 65 million records of passengers arriving at the Port of New York from 1820 to 1957. Inquire about having the American Family History Center open during your private event.',
    highlights: ['65 million passenger records', 'Guided genealogy research', 'Wall of Honor search', 'Unforgettable guest keepsake'],
  },
  {
    id: 'liberty-grounds',
    name: 'Liberty Island Grounds',
    island: 'Liberty Island',
    image: IMG.libertyNight,
    capacity: 'Outdoor events 500+ guests',
    setting: 'Outdoor',
    short: 'Cocktails at the feet of Lady Liberty, set on 12 acres in New York Harbor.',
    description:
      'Join Lady Liberty for a cocktail and a photo keepsake followed by dinner as you take in the stars and the Manhattan skyline. The Statue measures 305 ft 1 in from the ground to the tip of her torch — an event experience like no other.',
    highlights: ['12 acres in NY Harbor', 'Photo keepsake with Lady Liberty', 'Rangers on site', 'Firework spectacular available'],
  },
  {
    id: 'torch-gallery',
    name: 'Statue of Liberty Museum — Torch Gallery',
    island: 'Liberty Island',
    image: IMG.museum,
    capacity: '50 – 220 guests',
    setting: 'Indoor',
    short: "Dine alongside the Statue's original 1886 torch.",
    description:
      "Designed by Frédéric Auguste Bartholdi, with a skeleton devised by Gustave Eiffel, the Statue represents the deep friendship shared between the United States and France. Dine with the Statue's original torch in the award-winning Statue of Liberty Museum.",
    highlights: ["Dine with the original torch", 'Interactive exhibits', 'Selfie wall with Lady Liberty', 'Seated dinners & receptions'],
  },
  {
    id: 'green-roof',
    name: 'Museum Green Roof & Observation Deck',
    island: 'Liberty Island',
    image: IMG.greenRoof,
    capacity: '50 – 220 guests',
    setting: 'Outdoor',
    short: 'A living roofscape with sweeping views of the skyline, Lady Liberty and Ellis Island.',
    description:
      'Enjoy the green roofscape and observation deck providing stunning views of the NYC Skyline, Lady Liberty and Ellis Island — ideal for sunset cocktails before dinner in the museum below.',
    highlights: ['Panoramic harbor views', 'Sunset cocktail hour', 'Sustainable design', 'Pairs with Torch Gallery'],
  },
  {
    id: 'immersive-theater',
    name: 'Immersive Theater',
    island: 'Liberty Island',
    image: IMG.theater,
    capacity: 'Private presentations',
    setting: 'Indoor',
    short: 'A cinematic journey into how the Statue of Liberty came to be.',
    description:
      'Immersive theater, museum exhibits and interactive galleries are all at your disposal — perfect for product reveals, keynote moments or simply giving guests an unforgettable introduction to Lady Liberty.',
    highlights: ['Panoramic projection', 'Keynote & reveal moments', 'Museum-exclusive access', 'Combine with dinner'],
  },
];

export const INQUIRY_EVENT_TYPES = [
  'Corporate Gala',
  'Fundraiser / NGO Event',
  'Corporate Meeting / Conference',
  'Product Launch',
  'Holiday / Company Party',
  'Milestone Family Event',
  'Premiere / Fashion Gala',
  'Awards / Anniversary',
  'Other',
];

export const EVENT_TYPES = [
  { icon: 'Crown', title: 'Corporate Galas', inquiry: INQUIRY_EVENT_TYPES[0], text: 'Black-tie dinners and lavish corporate gatherings beneath the vaulted ceiling of the Great Hall.' },
  { icon: 'HeartHandshake', title: 'Fundraisers & NGO Events', inquiry: INQUIRY_EVENT_TYPES[1], text: 'Galvanize supporters at the symbol of hope and freedom — with galleries open for your guests.' },
  { icon: 'Presentation', title: 'Meetings & Conferences', inquiry: INQUIRY_EVENT_TYPES[2], text: 'Day events for up to 100 in the Conference Room overlooking the Great Hall.' },
  { icon: 'Rocket', title: 'Product Launches', inquiry: INQUIRY_EVENT_TYPES[3], text: 'Unveil what is next at America’s most recognized landmark, with immersive theater moments.' },
  { icon: 'Sparkles', title: 'Holiday & Company Parties', inquiry: INQUIRY_EVENT_TYPES[4], text: 'Holiday parties, employee appreciation days and company outings guests talk about for years.' },
  { icon: 'Users', title: 'Milestone Family Events', inquiry: INQUIRY_EVENT_TYPES[5], text: 'Family reunions and milestone celebrations that honor your heritage where it began.' },
  { icon: 'Clapperboard', title: 'Premieres & Fashion Galas', inquiry: INQUIRY_EVENT_TYPES[6], text: 'Movie premieres and Fashion Week galas with the Manhattan skyline as your backdrop.' },
  { icon: 'Award', title: 'Awards & Anniversaries', inquiry: INQUIRY_EVENT_TYPES[7], text: 'Award ceremonies, stockholder receptions and company anniversaries on Monumental grounds.' },
];

export const ENHANCEMENTS = [
  { icon: 'Flame', title: 'Firework Finale', text: 'The ultimate ending — a firework spectacular over New York Harbor.' },
  { icon: 'Ship', title: 'Private Ferry Charter', text: 'An exclusive 8–15 minute ride from Battery Park, NYC or Liberty State Park, NJ.' },
  { icon: 'UtensilsCrossed', title: 'Custom Culinary', text: 'All menus customized to your specifications with our top NYC catering partners.' },
  { icon: 'BookOpen', title: 'Heritage Research', text: 'Open the American Family History Center for guests to find their ancestors.' },
] as const;

export type GalleryCategory = 'Galas' | 'Corporate' | 'Venues' | 'Celebrations' | 'Fireworks';
export const GALLERY_CATEGORIES: ('All' | GalleryCategory)[] = ['All', 'Galas', 'Corporate', 'Venues', 'Celebrations', 'Fireworks'];

export const GALLERY: { src: string; title: string; category: GalleryCategory; tall?: boolean }[] = [
  { src: IMG.greatHallGala, title: 'Black-tie gala in the Great Hall', category: 'Galas' },
  { src: IMG.torchSunset, title: 'Lady Liberty at sunset', category: 'Venues', tall: true },
  { src: IMG.fireworksReal, title: 'Army–Navy 2022 firework finale', category: 'Fireworks' },
  { src: IMG.corporateEllis, title: 'Corporate event on Ellis Island', category: 'Corporate', tall: true },
  { src: IMG.torchDinner, title: 'Dinner with the original torch', category: 'Galas' },
  { src: IMG.awards, title: 'Awards ceremony', category: 'Corporate' },
  { src: IMG.family, title: 'Milestone family celebration', category: 'Celebrations' },
  { src: IMG.fireworks, title: 'Fireworks over the harbor', category: 'Fireworks' },
  { src: IMG.registryRoom, title: 'The Registry Room', category: 'Venues' },
  { src: IMG.fundraiser, title: 'Fundraiser cocktail hour', category: 'Galas' },
  { src: IMG.balconyMeeting, title: 'Leadership offsite', category: 'Corporate' },
  { src: IMG.lawnReception, title: 'Reception under the stars', category: 'Celebrations' },
  { src: IMG.plated, title: 'A culinary experience like no other', category: 'Celebrations' },
  { src: IMG.ferry, title: 'Arriving by private ferry', category: 'Venues' },
];

export const TESTIMONIALS = [
  {
    quote:
      'Our guests still talk about walking into the Great Hall. Patti and her team handled every detail with the National Park Service — it was the most seamless gala we have ever produced.',
    name: 'Director of Global Events',
    org: 'Financial Services Firm, NYC',
  },
  {
    quote:
      'Having the museum galleries open during our fundraiser gave the evening real meaning. Donors connected with the stories of immigrants who came through these halls.',
    name: 'Executive Director',
    org: 'National Non-Profit Foundation',
  },
  {
    quote:
      'Cocktails at the feet of Lady Liberty, dinner beside the original torch, then fireworks over the harbor. Truly a monumental evening.',
    name: 'Senior Producer',
    org: 'Corporate Event Agency',
  },
  {
    quote:
      'We brought three generations of our family back to where our story began. Finding our great-grandparents in the passenger records was unforgettable.',
    name: 'Private Host',
    org: 'Family Reunion, 180 guests',
  },
];

export const TEAM = [
  {
    name: 'Patti Golden',
    role: 'VP of Events',
    email: 'pgolden@ehillgroup.com',
    image: IMG.patti,
    linkedin: 'https://www.linkedin.com/in/pattigolden',
  },
  {
    name: 'Tara McGill',
    role: 'Senior Event Manager',
    email: 'tmcgill@ehillgroup.com',
    image: IMG.tara,
    linkedin: '',
  },
];

export const TIMELINE = [
  { year: '1892', text: 'Ellis Island opens as the nation’s busiest immigration station, welcoming 12 million by 1954.' },
  { year: '1931', text: 'Evelyn Hill Inc. begins providing hospitality services at the Statue of Liberty.' },
  { year: '1990', text: 'Ellis Island & Liberty Island begin welcoming corporate groups, dignitaries and productions for private events.' },
  { year: '2026', text: 'Celebrating 95 years — the oldest family-owned concessioner for the National Park Service.' },
];

export const STATS = [
  { value: '95', label: 'Years of hospitality' },
  { value: '1,200', label: 'Guests island-wide' },
  { value: '8 min', label: 'Private ferry ride' },
  { value: '12M', label: 'Immigrant stories' },
];

export const VIRTUAL_TOURS = [
  { title: 'Ellis Island Site Tour', href: 'https://ellisisland-events.com/ellis-island-site-tour', image: IMG.ellisExterior },
  { title: 'Ellis Island Tour', href: 'https://ellisisland-events.com/ellis-island-tour', image: IMG.registryRoom },
  { title: 'Liberty Island Tour', href: 'https://ellisisland-events.com/liberty-island-tour', image: IMG.torchSunset },
];

export const FAQS = [
  {
    q: 'What are the costs for an event?',
    a: 'A Special Use Permit Fee is paid directly to the National Park Service. Rates are determined by the National Park Service and are based upon your impact on the Monument, e.g. number of guests, length of event, etc. The fee can range from $9,000 for up to 99 guests up to $23,000 for 1,200 guests.',
  },
  {
    q: 'How do I get to Ellis & Liberty Islands?',
    a: 'Statue Cruises is the exclusive provider of transportation to Liberty & Ellis Islands from Battery Park, NYC or Liberty State Park, NJ. The ferry is privately used to transport you and your guests — the ride is under 15 minutes. Private ferries range from $9,700 to $17,500 depending on the ferry, paid directly to Statue Cruises. Ferries hold 400 to 800 guests and multiple ferries can be chartered.',
  },
  {
    q: 'Do my guests need to go through security?',
    a: 'Whether leaving Battery Park, NYC or Liberty State Park, NJ, your guests will be required to go through airport-style security with a metal detector — keeping America’s most treasured monuments safe.',
  },
  {
    q: 'What types of events are permitted?',
    a: 'All events must be approved by the National Park Service, showing a meaningful association to the Monument and its grounds. Fundraisers, corporate galas, company outings, black-tie affairs and product launches have all taken place on the Islands. You have the Island exclusively with National Park Service Rangers on site, and all museum galleries and exhibits are open for your guests. As of 2024, we are no longer permitted to host wedding events per the National Park Service.',
  },
  {
    q: 'What is the National Park Service involvement in my event?',
    a: 'The National Park Service manages both Liberty & Ellis Islands and must approve everything that occurs during your event, including date, number of guests, schedule and flow. Approval is obtained by submitting an NPS application at least 6 weeks prior to the event ($75 application fee). Evelyn Hill Inc. submits this application on your behalf.',
  },
  {
    q: 'Who is Evelyn Hill Inc.?',
    a: 'Evelyn Hill Inc. is the concessioner for the National Park Service managing the Crown Café, Ellis Island Café, both retail shops and the Special Events on each Island. We are a third-generation family-owned business that has operated at the Statue of Liberty for over 90 years, and we serve as your liaison to the National Park Service.',
  },
  {
    q: 'What time can my evening event start and end?',
    a: 'All private events must start after the Monuments close to the public. This timing varies by season and ranges from 5:15pm to 7pm — contact us with your date to confirm. All events must end at midnight per the National Park Service.',
  },
  {
    q: 'Will I be required to sign a contract and supply insurance?',
    a: 'Yes. The National Park Service requires a Certificate of Insurance naming the US Department of Interior, National Park Service as Additional Insured on the General Liability ($1,000,000). The Certificate Holder should read: Statue of Liberty NM, Liberty Island, NY 10004. Evelyn Hill Inc. will send a contract for all food and beverage.',
  },
];
