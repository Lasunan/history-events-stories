import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Loader2, ShieldAlert, LogOut, ArrowLeft } from 'lucide-react';
import { useAdminAuth } from '@/hooks/useAdminAuth';
import AdminLogin from '@/components/admin/AdminLogin';
import AdminDashboard from '@/components/admin/AdminDashboard';
import { CONTACT } from '@/data/site';

export default function Admin() {
  const { state, email, signOut } = useAdminAuth();

  useEffect(() => {
    document.title = 'Admin | Ellis Island Events';
    const meta = document.createElement('meta');
    meta.name = 'robots';
    meta.content = 'noindex, nofollow';
    document.head.appendChild(meta);
    return () => { meta.remove(); };
  }, []);

  if (state === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-ivory">
        <Loader2 className="w-8 h-8 animate-spin text-liberty-600" />
      </div>
    );
  }

  if (state === 'signed-out') return <AdminLogin />;

  if (state === 'not-admin') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-ivory p-6">
        <div className="max-w-md w-full bg-white shadow-sm border-t-4 border-liberty-600 p-8 text-center">
          <ShieldAlert className="w-12 h-12 text-liberty-600 mx-auto" strokeWidth={1.4} />
          <h1 className="font-serif text-2xl mt-4">Access Restricted</h1>
          <p className="mt-3 text-charcoal/70 text-sm leading-relaxed">
            You are signed in as <strong>{email}</strong>, but this account does not have admin access. Please contact{' '}
            <a href={`mailto:${CONTACT.email}`} className="text-liberty-700 hover:underline">{CONTACT.email}</a> to be added to the team.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
            <button onClick={signOut} className="btn-primary !py-2.5"><LogOut className="w-4 h-4" /> Sign Out</button>
            <Link to="/" className="btn-outline !py-2.5"><ArrowLeft className="w-4 h-4" /> Website</Link>
          </div>
        </div>
      </div>
    );
  }

  return <AdminDashboard email={email} onSignOut={signOut} />;
}
