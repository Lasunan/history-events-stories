import React from 'react';
import AppLayout from '@/components/AppLayout';
import { AppProvider } from '@/contexts/AppContext';
import type { PageSlug } from '@/data/pages';

const Index: React.FC<{ slug?: PageSlug }> = ({ slug = 'home' }) => {
  return (
    <AppProvider>
      <AppLayout slug={slug} />
    </AppProvider>
  );
};

export default Index;
