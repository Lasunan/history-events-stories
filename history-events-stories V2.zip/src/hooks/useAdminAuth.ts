import { useCallback, useEffect, useState } from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';

type State = 'loading' | 'signed-out' | 'not-admin' | 'admin';

/** Tracks the Supabase session and verifies the admin role via the is_admin() database function. */
export function useAdminAuth() {
  const [session, setSession] = useState<Session | null>(null);
  const [state, setState] = useState<State>('loading');

  const evaluate = useCallback(async (s: Session | null) => {
    setSession(s);
    if (!s) {
      setState('signed-out');
      return;
    }
    const { data, error } = await supabase.rpc('is_admin');
    setState(!error && data === true ? 'admin' : 'not-admin');
  }, []);

  useEffect(() => {
    let active = true;
    supabase.auth.getSession().then(({ data }) => active && evaluate(data.session));
    const { data: sub } = supabase.auth.onAuthStateChange((_event, s) => {
      // Defer to avoid calling Supabase inside the auth callback synchronously.
      setTimeout(() => active && evaluate(s), 0);
    });
    return () => {
      active = false;
      sub.subscription.unsubscribe();
    };
  }, [evaluate]);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setSession(null);
    setState('signed-out');
  }, []);

  return { session, state, email: session?.user.email ?? '', signOut };
}
